"""audiolab — course library for the Audio module of Informazione Multimediale.

Helper functions used in the labs: reading and describing audio files,
listening and plotting with Plotly, level and frequency measurements, tone and
noise generation, sound-wave figures, spectrum and feature analysis, DSP
(delays, filters, rooms) and the machine-learning pipelines of lessons 4 and 5.

Typical use, in a Jupyter notebook::

    import audiolab as al

The function manual is in ``lab-2026/manuale/`` (generated from the
docstrings).
"""

from . import analysis
from . import constants, paths, io, measures, synth, plotting, waves
from . import spectrum, features, dsp, classification, generation, vae, embeddings

from .constants import (
    SAMPLE_RATE,
    STANDARD_RATES,
    SPEED_OF_SOUND_AIR,
    P_REF,
    I_REF,
    NOTE_NAMES,
    TIMBRE_CLASSES,
    SYNTHETIC_CLASSES,
    URBAN_CLASSES,
    URBAN_CLASSES_BY_ID,
    URBAN_CONFIG,
)
from .paths import (
    PROJECT_ROOT,
    LAB_DIR,
    MATERIALS_DIR,
    AUDIO_DIR,
    DATASETS_DIR,
    project_root,
)
from .io import (
    load_audio,
    load_channels,
    file_info,
    size_mb,
    duration_seconds,
    listen,
    safe_audio,
    compare_audio,
    save_audio,
)
from .measures import (
    rms,
    to_db,
    to_dbfs,
    crest_factor,
    zero_crossing_rate,
    estimate_frequency,
    snr,
    db_pressure,
    db_intensity,
    peak_rms,
    block_rms,
)
from .synth import (
    time_axis,
    sine,
    sum_tones,
    chirp,
    envelope,
    quantize,
    downsample,
    resample,
    nyquist_rate,
    standard_rate_for,
    white_noise,
    pink_noise,
    sum_harmonics,
    decaying_tone,
    fade_edges,
    tone_with_envelope,
    add_silence,
    midi_to_frequency,
    synthetic_timbre,
    synthetic_chord,
    synthetic_event,
)
from .plotting import (
    plot_waveform,
    plot_waveforms,
    plot_channels,
    plot_signal_rows,
    plot_curves,
)
from .waves import (
    longitudinal_wave,
    space_time_demo,
    sinusoid_demo,
    same_amplitude_demo,
    phase_interference,
)
from .spectrum import (
    amplitude_spectrum,
    db_spectrum,
    plot_spectrum,
    plot_spectra,
    plot_spectrograms,
    plot_spectrogram,
    spectrogram_levels,
    fundamental_frequency,
    harmonic_levels,
    spectrum_slope,
)
from .features import (
    mel_spectrogram,
    stft_power,
    mel_filterbank,
    mel_frequencies,
    log_mel,
    mfcc_matrix,
    delta,
    add_noise,
    chroma_profile,
    plot_mel_filterbank,
    plot_mfcc,
    plot_chroma,
    time_features,
    spectral_features,
    mfcc_features,
    all_features,
    chord_templates,
    recognize_chord,
)
from .dsp import (
    delay_signal,
    delay_by,
    process,
    sos_response,
    voice_eq_chain,
    synthetic_impulse_response,
    estimate_t20,
    plucked_string,
    frequency_response,
    filter_signal,
    design_filter,
    eq_bell,
    eq_shelf,
    convolve,
    feedback_delay,
    modulated_delay,
    tremolo,
    saturate,
    compress,
    schroeder_reverb,
    instantaneous_frequency,
    filter_sos,
    phaser,
    compressor_curve,
)
from .classification import (
    urban_dataset_dir,
    urban_metadata,
    split_dataset,
    load_clip,
    representations,
    prepare_features,
    build_cnn,
    build_sound_cnn,
    predict,
    train_or_load_cnn,
    prepare_urban_data,
    train_network,
    plot_confusion,
    evaluate_features,
)
from .generation import (
    generate,
    load_samples,
)
from .vae import (
    download_model,
    mean_mfcc,
    reconstruction_metrics,
    generate_materials,
    load_materials,
)
from .embeddings import (
    CLAP_MODEL_ID,
    PHRASES,
    prepare_clap_embeddings,
)

__version__ = "1.0.0"

__all__ = [
    # modules
    "constants", "paths", "io", "measures", "synth", "plotting", "waves",
    "spectrum", "features", "dsp", "classification", "generation", "vae",
    "embeddings",
    # constants
    "SAMPLE_RATE", "STANDARD_RATES", "SPEED_OF_SOUND_AIR", "P_REF", "I_REF",
    "NOTE_NAMES", "TIMBRE_CLASSES", "SYNTHETIC_CLASSES", "URBAN_CLASSES",
    "URBAN_CLASSES_BY_ID", "URBAN_CONFIG",
    # paths
    "PROJECT_ROOT", "LAB_DIR", "MATERIALS_DIR", "AUDIO_DIR", "DATASETS_DIR",
    "project_root",
    # io
    "load_audio", "load_channels", "file_info", "size_mb", "duration_seconds",
    "listen", "safe_audio", "compare_audio",
    # measures
    "rms", "to_db", "to_dbfs", "crest_factor", "zero_crossing_rate",
    "estimate_frequency", "snr", "db_pressure", "db_intensity", "peak_rms",
    "block_rms",
    # synth
    "time_axis", "sine", "sum_tones", "envelope", "quantize", "downsample",
    "resample", "nyquist_rate", "standard_rate_for", "white_noise",
    "pink_noise", "sum_harmonics", "decaying_tone", "fade_edges",
    "tone_with_envelope", "add_silence", "midi_to_frequency",
    "synthetic_timbre", "synthetic_chord", "synthetic_event",
    # plotting
    "plot_waveform", "plot_waveforms", "plot_channels", "plot_signal_rows",
    "plot_curves",
    # waves
    "longitudinal_wave", "space_time_demo", "sinusoid_demo",
    "same_amplitude_demo", "phase_interference",
    # spectrum
    "amplitude_spectrum", "db_spectrum", "plot_spectrum", "plot_spectra",
    "plot_spectrograms", "plot_spectrogram", "spectrogram_levels",
    "fundamental_frequency", "harmonic_levels", "spectrum_slope",
    # features
    "mel_spectrogram", "plot_mel_filterbank", "plot_mfcc", "plot_chroma",
    "time_features", "spectral_features", "mfcc_features", "all_features",
    "chord_templates", "recognize_chord",
    # dsp
    "delay_signal", "delay_by", "process", "sos_response", "voice_eq_chain",
    "synthetic_impulse_response", "estimate_t20", "plucked_string",
    # classification
    "urban_dataset_dir", "urban_metadata", "split_dataset", "load_clip",
    "representations", "prepare_features", "build_cnn", "build_sound_cnn", "predict",
    "train_or_load_cnn", "prepare_urban_data", "train_network",
    "plot_confusion", "evaluate_features",
    # generation
    "generate", "load_samples",
    # vae
    "download_model", "mean_mfcc", "reconstruction_metrics",
    "generate_materials", "load_materials",
    # embeddings
    "CLAP_MODEL_ID", "PHRASES", "prepare_clap_embeddings",
]
