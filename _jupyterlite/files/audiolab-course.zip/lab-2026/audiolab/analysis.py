"""Portable audio analysis used by the browser demos.

NumPy/SciPy implementations of the STFT, its inverse and the Slaney/HTK
Mel pipeline. They run without Numba in Pyodide; desktop labs retain librosa.
The conventions (Hann periodic window, centred frames, DCT-II orthonormal)
are checked against librosa in the interactive-lab validation script.
"""
from types import SimpleNamespace
from math import gcd
import numpy as np
from scipy import signal, fft

__version__ = 'audiolab-portable-1'


def stft(y, n_fft=2048, hop_length=None, win_length=None, window='hann', center=True, pad_mode='constant'):
    """Complex STFT, with frequency rows and time columns (librosa conventions)."""
    y = np.asarray(y)
    hop_length = hop_length or (win_length or n_fft)//4
    win_length = win_length or n_fft
    if y.ndim != 1 or n_fft < win_length or hop_length < 1:
        raise ValueError('Segnale mono e parametri di finestra validi richiesti.')
    if center:
        y = np.pad(y, (n_fft//2, n_fft//2), mode=pad_mode)
    if len(y) < n_fft:
        raise ValueError('Segnale più corto della finestra senza padding.')
    w = signal.get_window(window, win_length, fftbins=True) if isinstance(window, str) else np.asarray(window)
    w = np.pad(w, ((n_fft-win_length)//2, n_fft-win_length-(n_fft-win_length)//2))
    frames = np.lib.stride_tricks.sliding_window_view(y, n_fft)[::hop_length]
    return np.fft.rfft(frames*w, axis=1).T


def istft(D, hop_length=None, win_length=None, n_fft=None, window='hann', center=True, length=None):
    """Invert a complex STFT by windowed overlap-add and weight correction."""
    n_fft = n_fft or 2*(D.shape[0]-1)
    win_length = win_length or n_fft
    hop_length = hop_length or win_length//4
    w = signal.get_window(window, win_length, fftbins=True) if isinstance(window, str) else np.asarray(window)
    w = np.pad(w, ((n_fft-win_length)//2, n_fft-win_length-(n_fft-win_length)//2))
    frames = np.fft.irfft(D.T, n=n_fft, axis=1)
    n = n_fft+hop_length*(len(frames)-1)
    out, weights = np.zeros(n), np.zeros(n)
    for i, frame in enumerate(frames):
        k = i*hop_length
        out[k:k+n_fft] += frame*w
        weights[k:k+n_fft] += w*w
    np.divide(out, weights, out=out, where=weights>np.finfo(float).tiny)
    start = n_fft//2 if center else 0
    if length is None:
        return out[start:n-start if start else n]
    out = out[start:start+length]
    return np.pad(out, (0, max(0,length-len(out))))


def fft_frequencies(sr=22050, n_fft=2048):
    return np.fft.rfftfreq(n_fft, 1/sr)


def frames_to_time(frames, sr=22050, hop_length=512):
    return np.asarray(frames)*hop_length/sr


def midi_to_hz(notes):
    return 440.0*2**((np.asarray(notes)-69)/12)


def note_to_hz(note):
    import re
    m = re.fullmatch(r'([A-Ga-g])([#b]?)(-?\d+)',note)
    if not m: raise ValueError('Nota attesa, per esempio C4.')
    step={'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}[m[1].upper()]
    step += {'':0,'#':1,'b':-1}[m[2]]
    return midi_to_hz(12*(int(m[3])+1)+step)


def power_to_db(S, ref=1.0, amin=1e-10, top_db=80):
    S = np.abs(np.asarray(S))
    reference = ref(S) if callable(ref) else abs(ref)
    db = 10*np.log10(np.maximum(amin,S))-10*np.log10(max(amin,reference))
    return np.maximum(db,db.max()-top_db) if top_db is not None else db


def amplitude_to_db(S, ref=1.0, amin=1e-5, top_db=80):
    S=np.abs(np.asarray(S)); reference=ref(S) if callable(ref) else abs(ref)
    return power_to_db(S*S,ref=reference**2,amin=amin**2,top_db=top_db)


def hz_to_mel(f, htk=False):
    f=np.asarray(f,dtype=float)
    if htk: return 2595*np.log10(1+f/700)
    return np.where(f>=1000,15+np.log(np.maximum(f,1e-30)/1000)/(np.log(6.4)/27),f/(200/3))


def mel_to_hz(m, htk=False):
    m=np.asarray(m,dtype=float)
    if htk: return 700*(10**(m/2595)-1)
    return np.where(m>=15,1000*np.exp((m-15)*(np.log(6.4)/27)),m*(200/3))


def mel_frequencies(n_mels=128, fmin=0.0, fmax=11025.0, htk=False):
    return mel_to_hz(np.linspace(hz_to_mel(fmin,htk),hz_to_mel(fmax,htk),n_mels),htk)


def mel(sr, n_fft, n_mels=128, fmin=0.0, fmax=None, htk=False, norm='slaney', dtype=np.float32):
    edges=mel_frequencies(n_mels+2,fmin,fmax or sr/2,htk)
    f=fft_frequencies(sr,n_fft)
    ramps=edges[:,None]-f
    widths=np.diff(edges)
    weights=np.maximum(0,np.minimum(-ramps[:-2]/widths[:-1,None],ramps[2:]/widths[1:,None]))
    if norm=='slaney': weights *= (2/(edges[2:]-edges[:-2]))[:,None]
    elif norm is not None: raise ValueError('Normalizzazione supportata: slaney oppure None.')
    return weights.astype(dtype)


def melspectrogram(y=None, sr=22050, S=None, n_fft=2048, hop_length=512, power=2.0, **kwargs):
    if S is None: S=abs(stft(y,n_fft=n_fft,hop_length=hop_length))**power
    return mel(sr,n_fft,n_mels=kwargs.pop('n_mels',128),**kwargs)@S


def mfcc(y=None, sr=22050, S=None, n_mfcc=20, **kwargs):
    if S is None: S=power_to_db(melspectrogram(y=y,sr=sr,**kwargs))
    return fft.dct(S,type=2,axis=0,norm='ortho')[:n_mfcc]


def spectral_centroid(y=None,sr=22050,S=None,n_fft=2048,hop_length=512):
    if S is None: S=abs(stft(y,n_fft=n_fft,hop_length=hop_length))
    f=fft_frequencies(sr,2*(S.shape[0]-1))[:,None]
    return (f*S).sum(0,keepdims=True)/np.maximum(S.sum(0,keepdims=True),1e-30)


def spectral_bandwidth(y=None,sr=22050,S=None,n_fft=2048,hop_length=512):
    if S is None: S=abs(stft(y,n_fft=n_fft,hop_length=hop_length))
    c=spectral_centroid(sr=sr,S=S)
    f=fft_frequencies(sr,2*(S.shape[0]-1))[:,None]
    return np.sqrt(((f-c)**2*S).sum(0,keepdims=True)/np.maximum(S.sum(0,keepdims=True),1e-30))


def spectral_rolloff(y=None,sr=22050,S=None,n_fft=2048,hop_length=512,roll_percent=.85):
    if S is None: S=abs(stft(y,n_fft=n_fft,hop_length=hop_length))
    k=np.argmax(np.cumsum(S,axis=0)>=roll_percent*S.sum(0),axis=0)
    return fft_frequencies(sr,2*(S.shape[0]-1))[k][None,:]


def spectral_flatness(y=None,S=None,n_fft=2048,hop_length=512,power=2.0,amin=1e-10):
    if S is None: S=abs(stft(y,n_fft=n_fft,hop_length=hop_length))
    P=np.maximum(amin,S**power)
    return np.exp(np.mean(np.log(P),axis=0,keepdims=True))/P.mean(0,keepdims=True)


def rms(y, frame_length=2048,hop_length=512,center=True):
    y=np.pad(y,(frame_length//2,frame_length//2)) if center else np.asarray(y)
    frames=np.lib.stride_tricks.sliding_window_view(y,frame_length)[::hop_length]
    return np.sqrt(np.mean(frames**2,axis=1))[None,:]


def zero_crossing_rate(y, frame_length=2048,hop_length=512,center=True):
    y=np.pad(y,(frame_length//2,frame_length//2),mode='edge') if center else np.asarray(y)
    frames=np.lib.stride_tricks.sliding_window_view(y,frame_length)[::hop_length]
    return np.mean(np.diff(np.signbit(frames),axis=1),axis=1)[None,:]*(frame_length-1)/frame_length


def delta(data,width=9,order=1,axis=-1,mode='interp'):
    return signal.savgol_filter(data,width,order,deriv=order,axis=axis,mode=mode)


def resample(y,orig_sr,target_sr):
    common=gcd(int(orig_sr),int(target_sr))
    return signal.resample_poly(y,int(target_sr)//common,int(orig_sr)//common)


def load(path,sr=22050,mono=True,duration=None):
    import soundfile as sf
    y,actual=sf.read(path,dtype='float32',always_2d=True)
    if duration is not None: y=y[:round(duration*actual)]
    y=y.mean(1) if mono else y.T
    return (resample(y,actual,sr),sr) if sr and sr!=actual else (y,actual)


def specshow(S,sr=22050,hop_length=512,x_axis=None,y_axis=None,ax=None,**kwargs):
    import matplotlib.pyplot as plt
    ax=ax or plt.gca()
    x=np.arange(S.shape[1])*hop_length/sr
    y=(mel_frequencies(S.shape[0],fmax=sr/2) if y_axis=='mel' else
       np.linspace(0,sr/2,S.shape[0]) if y_axis in ('linear','log') else np.arange(S.shape[0]))
    result=ax.pcolormesh(x,y,S,shading='auto',**kwargs)
    if y_axis=='log': ax.set_yscale('log')
    if x_axis=='time': ax.set_xlabel('Tempo [s]')
    return result

filters=SimpleNamespace(mel=mel)
feature=SimpleNamespace(melspectrogram=melspectrogram,mfcc=mfcc,spectral_centroid=spectral_centroid,
    spectral_bandwidth=spectral_bandwidth,spectral_rolloff=spectral_rolloff,
    spectral_flatness=spectral_flatness,rms=rms,zero_crossing_rate=zero_crossing_rate,delta=delta)
display=SimpleNamespace(specshow=specshow)
