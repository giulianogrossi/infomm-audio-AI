"""Classification support: UrbanSound8K data, caches and CNN training.

Reproducible support for chapter 4: metadata, splits, feature caches and CNN
training. No automatic downloads. The test split is never used to choose the
checkpoint.

The pipeline uses the official UrbanSound8K layout (WAV files in
``audio/foldN``) or the course MP3 copy, keeping the same folds.
"""

import copy
import csv
import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import sys
if sys.platform == "emscripten":
    from . import analysis as librosa
else:
    import librosa

from .plotting import _autoshow
from .constants import SAMPLE_RATE, URBAN_CLASSES_BY_ID, URBAN_CONFIG
from .features import mel_spectrogram


def urban_dataset_dir():
    """Directory of the UrbanSound8K dataset.

    Uses the ``URBANSOUND8K`` environment variable when set, otherwise the
    default ``~/Downloads/UrbanSound8K``.

    Returns
    -------
    pathlib.Path
        The dataset directory.

    Examples
    --------
    >>> path = al.urban_dataset_dir()
    """
    return Path(os.environ.get("URBANSOUND8K", "~/Downloads/UrbanSound8K")).expanduser()


def urban_metadata(folder):
    """Read the metadata of UrbanSound8K, from the official CSV or the course copy.

    Parameters
    ----------
    folder : str or pathlib.Path
        The dataset directory (the one containing ``metadata/UrbanSound8K.csv``).

    Returns
    -------
    list of dict
        One dictionary per clip, with the keys ``file`` (pathlib.Path string),
        ``fold`` (int), ``label`` (int class id) and ``source`` (file stem
        before the first dash, used to detect clips from the same recording).

    Examples
    --------
    >>> records = al.urban_metadata(al.urban_dataset_dir())
    >>> print(len(records), "clip")
    """
    folder = Path(folder).expanduser().resolve()
    csv_path = folder / "metadata/UrbanSound8K.csv"
    if not csv_path.is_file():
        raise FileNotFoundError(f"Dataset mancante: {csv_path}. Imposta URBANSOUND8K.")
    records = []
    with csv_path.open(newline="") as f:
        reader = csv.DictReader(f)
        official = {"slice_file_name", "fold", "classID"}.issubset(reader.fieldnames)
        if not official and not {"filename", "classID"}.issubset(reader.fieldnames):
            raise ValueError("Schema CSV non riconosciuto.")
        for row in reader:
            if official:
                fold = int(row["fold"])
                path = folder / "audio" / f"fold{fold}" / row["slice_file_name"]
            else:
                # The local archive uses filename=UrbanSound8K/audio/foldN/name.mp3.
                relative = Path(row["filename"])
                path = folder / "audio" / relative.parent.name / relative.name
                fold = int(relative.parent.name.removeprefix("fold"))
            if not path.is_file():
                raise FileNotFoundError(path)
            records.append(dict(file=str(path), fold=fold, label=int(row["classID"]),
                                source=path.stem.split("-")[0]))
    print("Archivio ufficiale WAV" if official else
          "Copia didattica MP3: fold conservati, formato diverso dal benchmark WAV.")
    return records


def split_dataset(records, config=URBAN_CONFIG):
    """Split the records into train, validation and test by official folds.

    Sources appearing on more than one fold are excluded, so clips from the
    same recording never end up in different splits.

    Parameters
    ----------
    records : list of dict
        The list produced by ``urban_metadata()``.
    config : dict, default URBAN_CONFIG
        The pipeline configuration (seeds and per-class caps).

    Returns
    -------
    dict
        The keys "train", "val" and "test", each with a list of records.

    Examples
    --------
    >>> split = al.split_dataset(records)
    """
    rng = np.random.default_rng(config["seed"])
    groups = {}
    for r in records:
        groups.setdefault(r["source"], set()).add(r["fold"])
    excluded = {k for k, v in groups.items() if len(v) > 1}
    if excluded:
        print("Sorgenti su più fold, escluse dal confronto didattico:",
              ", ".join(sorted(excluded)))
    records = [r for r in records if r["source"] not in excluded]
    split = {}
    for name, folds, cap in [("train", set(range(1, 9)), config["train_per_class"]),
                             ("val", {9}, config["val_per_class"]),
                             ("test", {10}, config["test_per_class"])]:
        selected = []
        for label in range(10):
            candidates = sorted((r for r in records
                                 if r["fold"] in folds and r["label"] == label),
                                key=lambda r: r["file"])
            if not candidates:
                raise ValueError(f"Classe {label} assente nello split {name}.")
            idx = rng.choice(len(candidates), min(cap, len(candidates)), replace=False)
            selected.extend(candidates[i] for i in idx)
        split[name] = selected
    groups = {k: {r["source"] for r in v} for k, v in split.items()}
    assert not (groups["train"] & groups["val"] or groups["train"] & groups["test"] or
                groups["val"] & groups["test"])
    return split


def load_clip(path, sr=SAMPLE_RATE, seconds=4.0):
    """Load a clip in mono and bring it exactly to ``seconds`` seconds.

    Shorter files are padded with zeros at the end.

    Parameters
    ----------
    path : str or pathlib.Path
        The audio file.
    sr : int, default SAMPLE_RATE
        Working sampling rate.
    seconds : float, default 4.0
        Requested duration, in seconds.

    Returns
    -------
    numpy.ndarray
        The fixed-length signal (``float32``).

    Examples
    --------
    >>> clip = al.load_clip(records[0]["file"], sr=22050)
    >>> print(len(clip) / 22050)   # 4.0
    """
    y, _ = librosa.load(path, sr=sr, mono=True, duration=seconds)
    if not len(y) or not np.all(np.isfinite(y)):
        raise ValueError(f"Audio vuoto o non finito: {path}")
    n = round(sr * seconds)
    return np.pad(y[:n], (0, max(0, n - len(y)))).astype(np.float32)


def representations(signal, config=URBAN_CONFIG):
    """Log-Mel spectrogram and MFCC statistics of a clip.

    Parameters
    ----------
    signal : numpy.ndarray
        The clip.
    config : dict, default URBAN_CONFIG
        Analysis parameters.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The log-Mel spectrogram and the vector of mean and standard deviation
        of the MFCCs (26 numbers with the defaults).

    Examples
    --------
    >>> logmel, mfcc_stats = al.representations(al.load_clip(path, sr=22050))
    """
    power = np.abs(librosa.stft(signal, n_fft=config["n_fft"],
                                hop_length=config["hop_length"], window="hann",
                                center=True)) ** 2
    mel = librosa.feature.melspectrogram(S=power, sr=config["sr"],
                                         n_fft=config["n_fft"],
                                         n_mels=config["n_mels"],
                                         htk=config["htk"], norm=config["norm"])
    logmel = librosa.power_to_db(mel, ref=1.0, top_db=80)
    mfcc = librosa.feature.mfcc(S=logmel, n_mfcc=config["n_mfcc"])
    return logmel.astype(np.float32), np.concatenate([mfcc.mean(1), mfcc.std(1)]).astype(np.float32)


def prepare_features(split, directory, config=URBAN_CONFIG):
    """Compute (or reload) the feature cache for a split.

    The cache is invalidated by changes in the configuration, in this module's
    code, in the library versions or in the audio files.

    Parameters
    ----------
    split : dict
        The splits produced by ``split_dataset()``.
    directory : str or pathlib.Path
        Where the cache is written.
    config : dict, default URBAN_CONFIG
        The pipeline configuration.

    Returns
    -------
    (dict, str)
        The data (keys such as "train_mel", "train_feat", "train_y") and the
        cache key.

    Examples
    --------
    >>> data, key = al.prepare_features(split, al.project_root() / "output/classificazione")
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    signature = dict(
        config=config,
        codice=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        librosa=librosa.__version__,
        numpy=np.__version__,
        files=[(k, r["file"], Path(r["file"]).stat().st_size,
                Path(r["file"]).stat().st_mtime_ns)
               for k, rs in split.items() for r in rs],
    )
    key = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()[:16]
    path = directory / f"feature-{key}.npz"
    start = time.perf_counter()
    if path.exists():
        with np.load(path) as z:
            data = {k: z[k] for k in z.files}
        print("Feature ricaricate dalla cache.")
    else:
        data = {}
        for name, rs in split.items():
            pairs = [representations(load_clip(r["file"], sr=config["sr"],
                                              seconds=config["duration"]), config)
                     for r in rs]
            data[f"{name}_mel"] = np.stack([c[0] for c in pairs])
            data[f"{name}_feat"] = np.stack([c[1] for c in pairs])
            data[f"{name}_y"] = np.array([r["label"] for r in rs], dtype=np.int64)
        np.savez_compressed(path, **data)
    (directory / f"manifest-{key}.json").write_text(
        json.dumps(dict(config=config, split=split), indent=2)
    )
    print(f"Preparazione feature: {time.perf_counter() - start:.1f} s (cache inclusa).")
    return data, key


def build_cnn(n_classes=10, channels=(16, 32, 64, 128)):
    """A simple CNN for the urban sounds: four convolution+ReLU+pool blocks, an
    adaptive pooling and a final linear layer.

    Parameters
    ----------
    n_classes : int, default 10
        Number of output classes.
    channels : tuple of int, default (16, 32, 64, 128)
        Number of channels of each block.

    Returns
    -------
    torch.nn.Module
        The network, ready for training (torch is imported inside).

    Examples
    --------
    >>> net = al.build_cnn()
    >>> print(sum(p.numel() for p in net.parameters()), "parametri")
    """
    import torch
    from torch import nn

    class SoundCNN(nn.Module):
        def __init__(self):
            super().__init__()
            self.blocks = nn.Sequential(
                *[self._block(i, o) for i, o in zip((1,) + channels[:-1], channels)])
            self.pool = nn.AdaptiveAvgPool2d((4, 4))
            self.classifier = nn.Sequential(
                nn.Flatten(), nn.Linear(channels[-1] * 4 * 4, n_classes))

        @staticmethod
        def _block(in_channels, out_channels):
            return nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
                nn.ReLU(),
                nn.MaxPool2d(kernel_size=2),
            )

        def forward(self, x):
            x = self.blocks(x)
            x = self.pool(x)
            return self.classifier(x)   # raw scores, not probabilities

    return SoundCNN()


def build_sound_cnn(n_classes=10, channels=(8, 16, 32, 64)):
    """The small network used by the cached training pipeline of chapter 4.

    Same idea as ``build_cnn()``, with a lighter classifier head suited to the
    reduced dataset of the chapter.

    Parameters
    ----------
    n_classes : int, default 10
        Number of output classes.
    channels : tuple of int, default (8, 16, 32, 64)
        Number of channels of each block.

    Returns
    -------
    torch.nn.Module
        The network, ready for training (torch is imported inside).

    Examples
    --------
    >>> net = al.build_sound_cnn()
    >>> print(sum(p.numel() for p in net.parameters()), "parametri")
    """
    import torch
    from torch import nn

    class SoundNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.blocks = nn.Sequential(*[
                nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2))
                for i, o in zip((1,) + channels[:-1], channels)])
            self.pool = nn.AdaptiveAvgPool2d((1, 1))
            self.head = nn.Linear(channels[-1], n_classes)

        def forward(self, x):
            return self.head(self.pool(self.blocks(x)).flatten(1))

    return SoundNet()


def predict(net, X, batch=32):
    """Class predictions for a batch of spectrograms.

    Parameters
    ----------
    net : torch.nn.Module
        The trained network.
    X : numpy.ndarray
        The spectrograms.
    batch : int, default 32
        Batch size.

    Returns
    -------
    numpy.ndarray
        The predicted class ids.

    Examples
    --------
    >>> predicted = al.predict(net, data["val_mel"][:, None])
    """
    import torch

    net.eval()
    with torch.no_grad():
        return np.concatenate([
            net(torch.as_tensor(X[i:i + batch], dtype=torch.float32)).argmax(1).numpy()
            for i in range(0, len(X), batch)])


def train_or_load_cnn(X_train, y_train, X_val, y_val, directory, key, epochs=8, seed=42):
    """Train the small network (or reload the weights from the cache).

    Model selection uses the macro-F1 of the validation split; the test split is
    never touched.

    Parameters
    ----------
    X_train, y_train : numpy.ndarray
        Training data and labels.
    X_val, y_val : numpy.ndarray
        Validation data and labels.
    directory : str or pathlib.Path
        Where the weights and the training log are written.
    key : str
        Cache key of the features (from ``prepare_features()``).
    epochs : int, default 8
        Maximum number of epochs.
    seed : int, default 42
        Seed for weights, shuffling and determinism.

    Returns
    -------
    (torch.nn.Module, dict)
        The network (best epoch) and the training metadata.

    Examples
    --------
    >>> net, meta = al.train_or_load_cnn(Xtr, ytr, Xval, yval, cache_dir, key)
    """
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
    from sklearn.metrics import f1_score

    torch.set_num_threads(min(4, torch.get_num_threads()))
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    net = build_sound_cnn()
    spec = dict(epochs=epochs, seed=seed, batch=32, lr=0.001, torch=str(torch.__version__))
    tag = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()[:8]
    path = Path(directory) / f"cnn-{key}-{tag}.pt"
    info = path.with_suffix(".json")
    if path.exists() and info.exists():
        net.load_state_dict(torch.load(path, map_location="cpu", weights_only=True))
        meta = json.loads(info.read_text())
        print("Pesi ricaricati:", path.name)
        return net, meta
    start = time.perf_counter()
    loader = DataLoader(TensorDataset(torch.tensor(X_train), torch.tensor(y_train)),
                        batch_size=32, shuffle=True,
                        generator=torch.Generator().manual_seed(seed))
    optimizer = torch.optim.Adam(net.parameters(), lr=0.001)
    loss_fn = nn.CrossEntropyLoss()
    history = []
    best = -1
    state = None
    best_epoch = 0
    for epoch in range(1, epochs + 1):
        net.train()
        total = 0
        for xb, yb in loader:
            optimizer.zero_grad()
            loss = loss_fn(net(xb), yb)
            loss.backward()
            optimizer.step()
            total += loss.item() * len(yb)
        pred_train = predict(net, X_train)
        pred_val = predict(net, X_val)
        f1 = f1_score(y_val, pred_val, labels=range(10), average="macro", zero_division=0)
        history.append(dict(epoch=epoch, loss=total / len(y_train),
                            train_f1=float(f1_score(y_train, pred_train, labels=range(10),
                                                    average="macro", zero_division=0)),
                            val_f1=float(f1)))
        if f1 > best:
            best = f1
            state = copy.deepcopy(net.state_dict())
            best_epoch = epoch
        print(f"Epoca {epoch}: loss {total / len(y_train):.3f}, macro-F1 val {f1:.3f}",
              flush=True)
    net.load_state_dict(state)
    meta = dict(config=spec, history=history, best_epoch=best_epoch,
                seconds=time.perf_counter() - start)
    torch.save(state, path)
    info.write_text(json.dumps(meta, indent=2))
    return net, meta


def prepare_urban_data(metadata, sr=SAMPLE_RATE, n_mels=64, n_fft=1024, hop=512,
                       n_train=100, n_test=15, fold_test=9, seed=0):
    """Extract a subset of clips for training (folds other than ``fold_test``)
    and one for testing (the ``fold_test`` fold), and turn them into tensors of
    standardised Mel spectrograms (statistics computed on the training set only).

    Parameters
    ----------
    metadata : list of dict
        The list produced by ``urban_metadata()``.
    sr : int, default SAMPLE_RATE
        Sampling rate in Hz used when loading every clip.
    n_mels : int, default 64
        Number of Mel bands (see ``mel_spectrogram``).
    n_fft : int, default 1024
        FFT window length in samples.
    hop : int, default 512
        Hop between analysis frames, in samples.
    n_train, n_test : int
        Clips per class in the training and test sets.
    fold_test : int, default 9
        The official fold kept for the test.
    seed : int, default 0
        Seed of the random choice of the clips.

    Returns
    -------
    dict
        With "X_train", "y_train", "X_test", "y_test", "mean", "std" and
        "test_clips" (the test clips, in the same order).

    Examples
    --------
    >>> data = al.prepare_urban_data(records, sr=22050, n_train=60, n_test=10)
    >>> print(data["X_train"].shape)
    """
    import torch

    rng = np.random.default_rng(seed)
    X_tr, y_tr, X_te, y_te, test_clips = [], [], [], [], []
    for label, name in sorted(URBAN_CLASSES_BY_ID.items()):
        available = [c for c in metadata if c["label"] == label]
        train_pool = [c for c in available if c["fold"] != fold_test]
        test_pool = [c for c in available if c["fold"] == fold_test]
        chosen_test = [test_pool[i] for i in
                       rng.choice(len(test_pool), size=min(n_test, len(test_pool)), replace=False)]
        chosen_train = [train_pool[i] for i in
                        rng.choice(len(train_pool), size=min(n_train, len(train_pool)), replace=False)]
        for c in chosen_train:
            X_tr.append(mel_spectrogram(load_clip(c["file"], sr=sr, seconds=4.0),
                                        sr=sr, n_mels=n_mels, n_fft=n_fft, hop=hop))
            y_tr.append(label)
        for c in chosen_test:
            X_te.append(mel_spectrogram(load_clip(c["file"], sr=sr, seconds=4.0),
                                        sr=sr, n_mels=n_mels, n_fft=n_fft, hop=hop))
            y_te.append(label)
            test_clips.append(c)

    X_tr = np.stack(X_tr).astype(np.float32)
    X_te = np.stack(X_te).astype(np.float32)

    mean, std = float(X_tr.mean()), float(X_tr.std())
    X_tr = (X_tr - mean) / std
    X_te = (X_te - mean) / std

    return {"X_train": torch.tensor(X_tr)[:, None], "y_train": torch.tensor(y_tr),
            "X_test": torch.tensor(X_te)[:, None], "y_test": torch.tensor(y_te),
            "mean": mean, "std": std, "test_clips": test_clips}


def train_network(net, X, y, epochs=4, batch=32, lr=1e-3, seed=0):
    """Train the network and print one line per epoch; return the history.

    Parameters
    ----------
    net : torch.nn.Module
        The network to train (see ``build_cnn``).
    X, y : torch.Tensor
        Training data and labels.
    epochs : int, default 4
        Number of passes over the whole dataset.
    batch : int, default 32
        Batch size.
    lr : float, default 1e-3
        Adam learning rate.
    seed : int, default 0
        Seed for the order of the batches.

    Returns
    -------
    list of (float, float) pairs
        (loss, accuracy) at the end of each epoch.

    Examples
    --------
    >>> history = al.train_network(al.build_cnn(n_classes=4), X, y, epochs=8)
    """
    import torch
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(seed)
    data = TensorDataset(X, y)
    loader = DataLoader(data, batch_size=batch, shuffle=True)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)

    history = []
    for epoch in range(1, epochs + 1):
        net.train()
        total_loss, correct, total = 0.0, 0, 0
        for xb, yb in loader:
            optimizer.zero_grad()
            scores = net(xb)
            loss = loss_fn(scores, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(yb)
            correct += (scores.argmax(dim=1) == yb).sum().item()
            total += len(yb)
        history.append((total_loss / total, correct / total))
        print(f"epoca {epoch:2d}   loss {total_loss / total:.3f}   "
              f"accuratezza sul train {correct / total:.1%}")
    return history


def plot_confusion(true, predicted, names, labels=None, title="Matrice di confusione"):
    """The confusion matrix as a Plotly heat map, with the counts in the cells.

    Parameters
    ----------
    true, predicted : sequence of int
        The true and predicted labels (numbers from 0 to ``len(names) - 1``).
    names : list of str
        The class names, in label order.
    labels : sequence or None, default None
        The label values (when absent: 0, 1, 2, ...).
    title : str, default "Matrice di confusione"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_confusion(true, predicted, class_names, title="Sul fold di prova")
    """
    import plotly.graph_objects as go
    from sklearn.metrics import confusion_matrix

    if labels is None:
        labels = list(range(len(names)))
    cm = confusion_matrix(true, predicted, labels=labels)
    text = [[str(v) if v else "" for v in row] for row in cm]
    fig = go.Figure(go.Heatmap(x=names, y=names, z=cm, colorscale="Blues",
                               text=text, texttemplate="%{text}",
                               hovertemplate="vera %{y}<br>predetta %{x}<br>%{z}<extra></extra>"))
    fig.update_layout(title=title, xaxis_title="classe predetta", yaxis_title="classe vera",
                      height=560, yaxis_autorange="reversed")
    return fig


def evaluate_features(dataset, feature_sets, test_size=0.3, seed=0):
    """Compare several feature sets on the same labelled dataset.

    Trains a random forest for each feature set and prints accuracy and
    macro-F1 on the test split (stratified).

    Parameters
    ----------
    dataset : list of (numpy.ndarray, str) pairs
        The examples: signal and label.
    feature_sets : list of (str, function) pairs
        Each function turns a signal into a feature vector.
    test_size : float, default 0.3
        Fraction of examples used for the check.
    seed : int, default 0
        Seed for the split and the classifier.

    Returns
    -------
    dict
        For each name, the pair (accuracy, macro-F1).

    Examples
    --------
    >>> results = al.evaluate_features(dataset, [("tempo", al.time_features),
    ...                                          ("MFCC", al.mfcc_features)])
    """
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import accuracy_score, f1_score

    labels = np.array([c for _, c in dataset])
    results = {}
    for name, function in feature_sets:
        X = np.array([function(y) for y, _ in dataset])
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, labels, test_size=test_size, stratify=labels, random_state=seed)
        clf = RandomForestClassifier(n_estimators=200, random_state=seed)
        clf.fit(X_tr, y_tr)
        pred = clf.predict(X_te)
        acc = float(accuracy_score(y_te, pred))
        macro_f1 = float(f1_score(y_te, pred, average="macro"))
        results[name] = (acc, macro_f1)
        print(f"{name:24s}  dim={X.shape[1]:3d}   accuratezza={acc:.2f}   macro-F1={macro_f1:.2f}")
    return results


plot_confusion = _autoshow(plot_confusion)
