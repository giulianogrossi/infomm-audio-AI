"""Shared constants of the course library.

Course library for *Informazione Multimediale* — Audio module.
This module collects the physical constants, the standard sampling rates and the
class-name tables used across the labs.
"""

#: Default sampling rate of the course (Hz).
SAMPLE_RATE = 44_100

#: Standard sampling rates, in increasing order (Hz).
STANDARD_RATES = [8_000, 11_025, 16_000, 22_050, 32_000, 44_100, 48_000, 96_000]

#: Speed of sound in air at about 20 degrees Celsius (m/s).
SPEED_OF_SOUND_AIR = 343.0

#: Reference pressure for the sound pressure level (Pa).
P_REF = 20e-6

#: Reference intensity for the sound intensity level (W/m^2).
I_REF = 1e-12

#: Names of the twelve pitch classes, starting from C.
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

#: The four synthetic timbre families used in chapter 4 (display names).
TIMBRE_CLASSES = ["flauto", "clarinetto", "archi", "percussioni"]

#: The four toy event classes used in chapter 4 (display names).
SYNTHETIC_CLASSES = ["clacson", "sirena", "abbaiare", "trapano"]

#: UrbanSound8K class names, ordered by class id.
URBAN_CLASSES = [
    "air_conditioner",
    "car_horn",
    "children_playing",
    "dog_bark",
    "drilling",
    "engine_idling",
    "gun_shot",
    "jackhammer",
    "siren",
    "street_music",
]

#: UrbanSound8K class names by class id.
URBAN_CLASSES_BY_ID = dict(enumerate(URBAN_CLASSES))

#: Configuration of the chapter-4 pipeline (features, splits, caches).
URBAN_CONFIG = dict(
    sr=22_050,
    duration=4.0,
    n_fft=1024,
    hop_length=512,
    n_mels=64,
    n_mfcc=13,
    htk=False,
    norm="slaney",
    seed=42,
    train_per_class=60,
    val_per_class=10,
    test_per_class=15,
)
