"""Digital signal processing: delays, filters, room responses and comparisons.

Delays and echoes, Pedalboard chains, SOS filter responses, synthetic impulse
responses with T20 estimation, and the Karplus-Strong plucked string.
"""

import numpy as np
import scipy.signal

from .constants import SAMPLE_RATE
from .synth import add_silence


def delay_signal(signal, delay_s, gain=1.0, sr=SAMPLE_RATE):
    """Add to the direct signal a delayed, attenuated copy: the simplest echo.

    The output is longer than the input by the delay time.

    Parameters
    ----------
    signal : numpy.ndarray
        The direct signal.
    delay_s : float
        Delay of the copy, in seconds.
    gain : float, default 1.0
        Attenuation of the copy (1 = same amplitude).
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        Direct + delayed copy.

    Examples
    --------
    >>> ping = al.sine(1000, 0.05)
    >>> with_echo = al.delay_signal(ping, 0.08, gain=0.6)
    >>> al.safe_audio(with_echo)
    """
    n = int(round(delay_s * sr))
    out = np.zeros(len(signal) + n)
    out[: len(signal)] += signal
    out[n : n + len(signal)] += gain * signal
    return out


def delay_by(signal, seconds, sr=SAMPLE_RATE):
    """Delay the signal by ``seconds``, adding zeros at the beginning.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (mono or multi-channel).
    seconds : float
        The delay, in seconds (non-negative).
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The delayed signal, longer than the input by the delay time.

    Examples
    --------
    >>> ping = np.zeros(al.SAMPLE_RATE//10); ping[0] = 1
    >>> delayed = al.delay_by(ping, 0.05)
    """
    n = round(seconds * sr)
    if n < 0:
        raise ValueError("Il ritardo deve essere non negativo.")
    return np.pad(signal, [(n, 0)] + [(0, 0)] * (np.asarray(signal).ndim - 1))


def process(board, signal, sr=SAMPLE_RATE, tail=0.0):
    """Process the signal with a Pedalboard chain.

    The silence tail is passed through the same effects, so the reverb (or the
    echo) rings to the end.

    Parameters
    ----------
    board : pedalboard.Pedalboard
        The effect chain.
    signal : numpy.ndarray
        The signal (mono or two columns).
    sr : int, default SAMPLE_RATE
        Sampling rate.
    tail : float, default 0.0
        Silence added after the signal, in seconds.

    Returns
    -------
    numpy.ndarray
        The output of the chain.

    Examples
    --------
    >>> from pedalboard import Pedalboard, Reverb
    >>> reverb = Pedalboard([Reverb(room_size=0.5, wet_level=0.3)])
    >>> wet = al.process(reverb, al.sine(440, 0.5), al.SAMPLE_RATE, tail=1.0)
    """
    z = add_silence(np.asarray(signal, dtype=np.float32), tail, sr)
    data = np.ascontiguousarray(z.T if z.ndim == 2 else z)
    out = board.process(data, sr, reset=True)
    return out.T if z.ndim == 2 else out


def sos_response(sos, sr=SAMPLE_RATE):
    """Frequency response of an SOS filter (second-order sections).

    The curve to plot or to search for values.

    Parameters
    ----------
    sos : numpy.ndarray
        The sections of the filter, as returned by scipy.signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The frequencies in Hz and the gain in dB.

    Examples
    --------
    >>> from scipy import signal
    >>> sos = signal.butter(4, 1000, "lowpass", fs=al.SAMPLE_RATE, output="sos")
    >>> f, gain = al.sos_response(sos)
    >>> print(f"a 1000 Hz: {gain[abs(f - 1000).argmin()]:.1f} dB")
    """
    f, h = scipy.signal.freqz_sos(sos, worN=8192, fs=sr)
    return f, 20 * np.log10(np.maximum(np.abs(h), 1e-12))


def voice_eq_chain():
    """Example equalisation chain for the voice (from demo 2).

    High-pass at 80 Hz, bell at 1.2 kHz (+5 dB), low shelf (-4 dB) and high
    shelf (-3 dB): the parameters are a test to verify, not a universal recipe.

    Returns
    -------
    pedalboard.Pedalboard
        The chain ready to be used with ``process()``.

    Examples
    --------
    >>> voice, sr = al.load_audio(al.AUDIO_DIR / "speech1.wav", seconds=3)
    >>> voice_eq = al.process(al.voice_eq_chain(), voice, sr)
    >>> al.compare_audio([("originale", voice), ("equalizzata", voice_eq)], sr)
    """
    from pedalboard import (
        Pedalboard,
        HighpassFilter,
        LowShelfFilter,
        PeakFilter,
        HighShelfFilter,
    )

    return Pedalboard(
        [
            HighpassFilter(cutoff_frequency_hz=80),
            LowShelfFilter(cutoff_frequency_hz=220, gain_db=-4),
            PeakFilter(cutoff_frequency_hz=1200, gain_db=5, q=1.2),
            HighShelfFilter(cutoff_frequency_hz=6000, gain_db=-3),
        ]
    )


def synthetic_impulse_response(rt60=0.8, sr=SAMPLE_RATE, seed=7):
    """Synthetic impulse response of a room, without direct arrival.

    Noise filtered with an exponential decay linked to ``rt60`` and three
    discrete reflections; no direct impulse (it is added separately in the
    mix). The fixed filter colours the tail, but does not create a different
    RT60 per frequency.

    Parameters
    ----------
    rt60 : float, default 0.8
        Nominal decay time, in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    seed : int, default 7
        Generator seed for reproducible results.

    Returns
    -------
    numpy.ndarray
        The impulse response (``float32``).

    Examples
    --------
    >>> h_room = al.synthetic_impulse_response(rt60=0.8, sr=al.SAMPLE_RATE)
    >>> wet = scipy.signal.fftconvolve(Guitar, h_room)
    """
    if rt60 <= 0:
        raise ValueError("rt60 deve essere positivo.")
    duration = max(0.2, 1.5 * rt60)
    t = np.arange(round(duration * sr)) / sr
    rng = np.random.default_rng(seed)
    noise = scipy.signal.sosfilt(
        scipy.signal.butter(2, 4000, fs=sr, output="sos"), rng.standard_normal(len(t))
    )
    noise /= np.sqrt(np.mean(noise**2))
    h = noise * np.exp(-np.log(1000) * t / rt60)
    h[: round(0.01 * sr)] = 0
    h *= 0.35 / np.linalg.norm(h)
    for delay, g in ((0.017, 0.25), (0.031, 0.18), (0.047, 0.12)):
        h[round(delay * sr)] += g
    return h.astype(np.float32)


def estimate_t20(h, sr=SAMPLE_RATE):
    """Estimate T20 from the Schroeder energy decay curve.

    Backward cumulative sum of the squares, regression from -5 to -25 dB and
    extrapolation to 60 dB with ``T20 = -60/m``.

    Parameters
    ----------
    h : numpy.ndarray
        The impulse response.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    (float, numpy.ndarray, numpy.ndarray, numpy.ndarray, numpy.ndarray)
        T20 in seconds, times, curve in dB, mask of the segment used and
        regression line.

    Examples
    --------
    >>> t20, t, level, segment, line = al.estimate_t20(al.synthetic_impulse_response(rt60=0.45), al.SAMPLE_RATE)
    >>> print(round(t20, 2), "s")
    """
    h = np.asarray(h, dtype=np.float64)
    energy = np.cumsum(h[::-1] ** 2)[::-1]
    if energy[0] <= 0:
        raise ValueError("Risposta priva di energia.")
    level = 10 * np.log10(np.maximum(energy / energy[0], 1e-12))
    t = np.arange(len(h)) / sr
    segment = (level >= -25) & (level <= -5)
    if segment.sum() < 20:
        raise ValueError("Intervallo di regressione insufficiente.")
    m, b = np.polyfit(t[segment], level[segment], 1)
    if m >= 0:
        raise ValueError("Decadimento non valido.")
    return -60 / m, t, level, segment, m * t + b


def plucked_string(f0, duration=1.5, gain=0.995, seed=3, sr=SAMPLE_RATE):
    """Synthetic string after Karplus-Strong: a recirculated delay with averaging.

    The delay sets the pitch, the average and the gain set the decay. A minimal
    model, not a complete guitar.

    Parameters
    ----------
    f0 : float
        Target frequency, in Hz (0 < f0 < Nyquist).
    duration : float, default 1.5
        Duration in seconds.
    gain : float, default 0.995
        Feedback gain (0 < gain < 1).
    seed : int, default 3
        Generator seed for reproducible results.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The string signal (``float32``).

    Examples
    --------
    >>> strings = [(f"{f} Hz", al.plucked_string(f)) for f in (110, 220, 440)]
    >>> al.compare_audio(strings)
    """
    if not 0 < f0 < sr / 2 or not 0 < gain < 1:
        raise ValueError("Usa 0 < f0 < Nyquist e 0 < gain < 1.")
    N = max(2, round(sr / f0))
    rng = np.random.default_rng(seed)
    buffer = rng.uniform(-0.25, 0.25, N)
    y = np.zeros(round(duration * sr), dtype=np.float32)
    for i in range(len(y)):
        j = i % N
        y[i] = buffer[j]
        buffer[j] = gain * 0.5 * (buffer[j] + buffer[(j + 1) % N])
    return y


def frequency_response(b, a, sr=SAMPLE_RATE, worN=8192):
    """Frequency response of a filter given its coefficients ``b``, ``a``.

    The curve to plot, to search for values (cut-off, peak, band) or to compare
    with a measured spectrum.

    Parameters
    ----------
    b, a : array_like
        Numerator and denominator coefficients of the filter.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    worN : int, default 8192
        Number of frequencies computed between 0 and ``sr / 2``.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The frequencies in Hz and the gain in dB.

    Examples
    --------
    >>> b = np.ones(8) / 8
    >>> f, gain = al.frequency_response(b, [1.0])
    >>> al.plot_curves([("media 8", f, gain)], x_title="Hz", y_title="dB")
    """
    b = np.atleast_1d(np.asarray(b, dtype=float))
    a = np.atleast_1d(np.asarray(a, dtype=float))
    f, h = scipy.signal.freqz(b, a, worN=worN, fs=sr)
    return f, 20 * np.log10(np.maximum(np.abs(h), 1e-12))


def filter_signal(b, a, signal):
    """Apply a digital filter (coefficients ``b``, ``a``) to a signal.

    Parameters
    ----------
    b, a : array_like
        Numerator and denominator coefficients of the filter.
    signal : numpy.ndarray
        The signal to filter.

    Returns
    -------
    numpy.ndarray
        The filtered signal, same length as the input.

    Examples
    --------
    >>> b, a = al.eq_bell(1700, 500, 9, sr=10000, band_level_db=6)
    >>> equalizzata = al.filter_signal(b, a, sinusoide)
    """
    return scipy.signal.lfilter(
        np.atleast_1d(np.asarray(b, dtype=float)),
        np.atleast_1d(np.asarray(a, dtype=float)),
        np.asarray(signal, dtype=float),
    )


def design_filter(kind, cutoff, sr=SAMPLE_RATE, order=4, q=30.0):
    """Second-order sections of a Butterworth filter or of a notch.

    ``kind`` is ``"lowpass"``, ``"highpass"``, ``"bandpass"`` (Butterworth, of
    the given order) or ``"notch"`` (a single section centred on ``cutoff`` with
    quality factor ``q``).

    Parameters
    ----------
    kind : str
        ``"lowpass"``, ``"highpass"``, ``"bandpass"`` or ``"notch"``.
    cutoff : float or tuple
        Cut-off frequency in Hz; for ``"bandpass"`` a pair ``(low, high)``.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    order : int, default 4
        Order of the Butterworth filter (ignored by the notch).
    q : float, default 30.0
        Quality factor of the notch (ignored by the Butterworth filters).

    Returns
    -------
    numpy.ndarray
        The SOS sections, ready for ``sos_response()`` or ``scipy.signal.sosfilt()``.

    Examples
    --------
    >>> sos = al.design_filter("lowpass", 2000)
    >>> f, gain = al.sos_response(sos)
    >>> al.plot_curves([("passa-basso", f, gain)], x_title="Hz", y_title="dB")
    """
    if kind == "notch":
        b, a = scipy.signal.iirnotch(float(cutoff), q, fs=sr)
        return scipy.signal.tf2sos(b, a)
    if kind not in ("lowpass", "highpass", "bandpass"):
        raise ValueError("kind deve essere lowpass, highpass, bandpass o notch.")
    return scipy.signal.butter(order, cutoff, btype=kind, fs=sr, output="sos")


def eq_bell(f0, bandwidth, gain_db, sr=SAMPLE_RATE, band_level_db=None):
    """Bell (peaking) equaliser: centre, bandwidth and gain.

    The bandwidth is measured at ``band_level_db`` when given, otherwise at the
    mid-gain level between 0 dB and the peak.

    Parameters
    ----------
    f0 : float
        Centre frequency in Hz.
    bandwidth : float
        Width of the bell in Hz, at the level chosen by ``band_level_db``.
    gain_db : float
        Gain at the centre, in dB (positive boost, negative cut).
    sr : int, default SAMPLE_RATE
        Sampling rate.
    band_level_db : float or None
        Level (in dB) at which ``bandwidth`` is measured, for example 6 for the
        band at +6 dB of a +9 dB bell.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The coefficients ``b``, ``a`` of the second-order section.

    Examples
    --------
    >>> b, a = al.eq_bell(1700, 500, 9, sr=10000, band_level_db=6)
    >>> f, gain = al.frequency_response(b, a, sr=10000)
    """
    G = 10 ** (gain_db / 20)
    if gain_db == 0:
        return np.array([1.0]), np.array([1.0])
    GB2 = (1 + G ** 2) / 2 if band_level_db is None else 10 ** (band_level_db / 10)
    if not min(1.0, G ** 2) < GB2 < max(1.0, G ** 2):
        raise ValueError("band_level_db deve stare fra riferimento e centro.")
    beta = np.sqrt((GB2 - 1) / (G ** 2 - GB2)) * np.tan(np.pi * bandwidth / sr)
    c = np.cos(2 * np.pi * f0 / sr)
    b = np.array([1 + G * beta, -2 * c, 1 - G * beta]) / (1 + beta)
    a = np.array([1.0, -2 * c / (1 + beta), (1 - beta) / (1 + beta)])
    return b, a


def eq_shelf(cutoff, gain_db, kind="low", sr=SAMPLE_RATE):
    """Shelving equaliser: a finite gain on the low or on the high band.

    Parameters
    ----------
    cutoff : float
        Corner frequency of the shelf, in Hz.
    gain_db : float
        Gain of the shelf, in dB.
    kind : str, default "low"
        ``"low"`` for the low band, ``"high"`` for the high band.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The coefficients ``b``, ``a`` of the first-order filter.

    Examples
    --------
    >>> b, a = al.eq_shelf(2500, -9, "high")
    >>> f, gain = al.frequency_response(b, a)
    """
    G = 10 ** (gain_db / 20)
    beta = np.tan(np.pi * cutoff / sr)
    if kind == "high":
        beta = 1 / beta
    elif kind != "low":
        raise ValueError("kind deve essere low o high.")
    sign = 1 if kind == "low" else -1
    b = np.array([1 + G * beta, sign * (G * beta - 1)]) / (1 + beta)
    a = np.array([1.0, sign * (beta - 1) / (1 + beta)])
    return b, a


def convolve(signal, impulse):
    """Full linear convolution: the tail of the impulse response included.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    impulse : numpy.ndarray
        The impulse response.

    Returns
    -------
    numpy.ndarray
        The convolution, with ``N + L - 1`` samples.

    Examples
    --------
    >>> y = al.convolve(x, h)          # same as np.convolve(x, h)
    >>> print(len(y), len(x) + len(h) - 1)
    """
    return scipy.signal.fftconvolve(
        np.asarray(signal, dtype=float), np.asarray(impulse, dtype=float), mode="full"
    )


def feedback_delay(signal, delay_s, feedback=0.5, sr=SAMPLE_RATE):
    """Echo with feedback: one copy every ``delay_s``, each scaled by ``feedback``.

    The output has the length of the input (the copies are summed inside it): pad
    the signal first when the tail has to be heard.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    delay_s : float
        Delay between two copies, in seconds.
    feedback : float, default 0.5
        Gain of each copy with respect to the previous one (0 < feedback < 1).
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The signal with its repeats.

    Examples
    --------
    >>> x = np.pad(al.sine(440, 0.2), (0, round(2 * al.SAMPLE_RATE)))
    >>> eco = al.feedback_delay(x, 0.25, feedback=0.55)
    """
    signal = np.asarray(signal, dtype=float)
    D = int(round(delay_s * sr))
    if D <= 0:
        raise ValueError("delay_s deve essere positivo.")
    y = signal.copy()
    for start in range(D, len(y), D):
        stop = min(start + D, len(y))
        y[start:stop] += feedback * y[start - D:stop - D]
    return y


def modulated_delay(signal, sr=SAMPLE_RATE, delay_ms=5.0, depth_ms=1.0, rate_hz=5.0,
                    phase=0.0, delay_curve=None):
    """Read the signal with a sinusoidal delay: vibrato, chorus, flanger.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    delay_ms : float, default 5.0
        Mean delay, in milliseconds.
    depth_ms : float, default 1.0
        Peak deviation of the delay, in milliseconds.
    rate_hz : float, default 5.0
        Rate of the modulation, in Hz.
    phase : float, default 0.0
        Initial phase of the modulation, in radians (for stereo or multi-voice
        chorus).
    delay_curve : array_like or None, default None
        Optional delay in samples for each input sample. It overrides the
        sinusoidal parameters, for example for a slowly random chorus.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The delayed signal and the delay curve (in samples), for the figures.

    Examples
    --------
    >>> vibrato, D = al.modulated_delay(tono, delay_ms=5, depth_ms=1, rate_hz=5)
    """
    x = np.asarray(signal, dtype=float)
    n = np.arange(len(x))
    D = (sr / 1000 * (delay_ms + depth_ms * np.sin(2 * np.pi * rate_hz * n / sr + phase))
         if delay_curve is None else np.asarray(delay_curve, dtype=float))
    if D.shape != x.shape or not np.all(np.isfinite(D)) or np.any(D < -1e-12):
        raise ValueError("Il ritardo deve essere finito, non negativo e avere un valore per campione.")
    D = np.maximum(D, 0)
    return np.interp(n - D, n, x, left=0.0, right=0.0), D


def tremolo(signal, sr=SAMPLE_RATE, rate_hz=5.0, depth=0.8):
    """Amplitude modulation: the gain oscillates between ``1 - depth`` and 1.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    rate_hz : float, default 5.0
        Rate of the modulation, in Hz.
    depth : float, default 0.8
        Depth of the modulation, from 0 (no effect) to 1 (full off).

    Returns
    -------
    numpy.ndarray
        The modulated signal.

    Examples
    --------
    >>> tono = al.sine(440, 2.0, amplitude=0.2)
    >>> al.compare_audio([("tono", tono), ("tremolo", al.tremolo(tono, rate_hz=5))])
    """
    x = np.asarray(signal, dtype=float)
    t = np.arange(len(x)) / sr
    return (1 - depth / 2 + depth / 2 * np.sin(2 * np.pi * rate_hz * t)) * x


def saturate(signal, drive=8.0, peak=0.3):
    """Soft saturation with ``tanh``, normalised so that ``peak`` stays ``peak``.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    drive : float, default 8.0
        Amount of distortion: larger values make the curve steeper.
    peak : float, default 0.3
        Reference amplitude: an input at ``peak`` leaves the saturation at ``peak``.

    Returns
    -------
    numpy.ndarray
        The saturated signal.

    Examples
    --------
    >>> x = 0.3 * al.sine(440, 1.0)
    >>> y = al.saturate(x, drive=8)
    """
    x = np.asarray(signal, dtype=float)
    return peak * np.tanh(drive * x) / np.tanh(drive * peak)


def compress(signal, sr=SAMPLE_RATE, threshold_db=-24.0, ratio=4.0, attack_ms=10.0,
             release_ms=120.0, makeup_db=0.0):
    """Dynamic-range compression with one Pedalboard compressor.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    threshold_db : float, default -24.0
        Threshold of the compressor, in dB.
    ratio : float, default 4.0
        Compression ratio (4 = 4:1).
    attack_ms, release_ms : float
        Attack and release times, in milliseconds.
    makeup_db : float, default 0.0
        Make-up gain applied after the compressor, in dB.

    Returns
    -------
    numpy.ndarray
        The compressed signal.

    Examples
    --------
    >>> voce, sr = al.load_audio(al.AUDIO_DIR / "speech1.wav", seconds=3)
    >>> compressa = al.compress(voce, sr, threshold_db=-24, ratio=3)
    """
    from pedalboard import Compressor, Gain, Pedalboard

    board = Pedalboard(
        [
            Compressor(threshold_db=threshold_db, ratio=ratio,
                       attack_ms=attack_ms, release_ms=release_ms),
            Gain(gain_db=makeup_db),
        ]
    )
    return process(board, signal, sr, tail=0.0)


def _delayed(signal, samples):
    """Copy of the signal delayed by ``samples`` samples (same length)."""
    y = np.zeros_like(signal, dtype=float)
    samples = int(samples)
    if 0 < samples < len(signal):
        y[samples:] = signal[:-samples]
    elif samples == 0:
        y[:] = signal
    return y


def schroeder_reverb(signal, sr=SAMPLE_RATE, decay=0.8):
    """Schroeder reverb: four parallel feedback combs and two series all-pass filters.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    decay : float, default 0.8
        Time, in seconds, for the comb feedback to fall by 60 dB.

    Returns
    -------
    numpy.ndarray
        The reverberated signal.

    Examples
    --------
    >>> y = al.schroeder_reverb(x, al.SAMPLE_RATE)
    """
    x = np.asarray(signal, dtype=float)
    delays = [max(1, round(d * sr / 44100)) for d in (1533, 1613, 1493, 1153)]
    y = np.zeros(len(x), dtype=float)
    for D in delays:
        g = 10 ** (-3 * D / (sr * decay))
        y += 0.25 * _delayed(feedback_delay(x, D / sr, g, sr), D)
    for d in (223, 443):
        D = max(1, round(d * sr / 44100))
        v = feedback_delay(y, D / sr, 0.7, sr)
        y = -0.7 * v + _delayed(v, D)
    return y


def instantaneous_frequency(signal, sr=SAMPLE_RATE):
    """Instantaneous frequency from the analytic signal (Hilbert transform).

    Parameters
    ----------
    signal : numpy.ndarray
        The signal to analyse.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The instantaneous frequency, in Hz, one value per sample.

    Examples
    --------
    >>> f_i = al.instantaneous_frequency(vibrato, al.SAMPLE_RATE)
    >>> print(round(float(f_i.mean()), 1), "Hz")
    """
    x = np.asarray(signal, dtype=float)
    phase = np.unwrap(np.angle(scipy.signal.hilbert(x)))
    return np.gradient(phase) / (2 * np.pi) * sr


def filter_sos(sos, signal):
    """Apply a filter in second-order sections (SOS) to a signal.

    Parameters
    ----------
    sos : numpy.ndarray
        The sections, as returned by ``design_filter()`` or ``scipy.signal.butter``.
    signal : numpy.ndarray
        The signal to filter.

    Returns
    -------
    numpy.ndarray
        The filtered signal, same length as the input.

    Examples
    --------
    >>> sos = al.design_filter("lowpass", 2000)
    >>> filtrata = al.filter_sos(sos, voce)
    """
    return scipy.signal.sosfilt(np.asarray(sos, dtype=float), np.asarray(signal, dtype=float))


def phaser(signal, sr=SAMPLE_RATE, rate_hz=0.4, depth=0.7, centre_hz=800.0,
           feedback=0.2, mix=0.5):
    """Phaser: the direct signal summed with an all-pass cascade swept by an LFO.

    Parameters
    ----------
    signal : numpy.ndarray
        The input signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    rate_hz : float, default 0.4
        Rate of the sweeping LFO, in Hz.
    depth : float, default 0.7
        Depth of the sweep (0..1).
    centre_hz : float, default 800.0
        Centre frequency of the sweep, in Hz.
    feedback : float, default 0.2
        Amount of feedback in the all-pass chain.
    mix : float, default 0.5
        Balance between direct and processed signal (0 = dry, 1 = wet).

    Returns
    -------
    numpy.ndarray
        The processed signal.

    Examples
    --------
    >>> y = al.phaser(guit, al.SAMPLE_RATE, rate_hz=0.4, depth=0.7)
    """
    from pedalboard import Pedalboard, Phaser

    board = Pedalboard(
        [Phaser(rate_hz=rate_hz, depth=depth, centre_frequency_hz=centre_hz,
                feedback=feedback, mix=mix)]
    )
    return process(board, signal, sr, tail=0.0)


def compressor_curve(levels_db, threshold_db=-20.0, ratio=4.0):
    """Static compression curve: output level for each input level.

    Parameters
    ----------
    levels_db : float or numpy.ndarray
        Input levels, in dB.
    threshold_db : float, default -20.0
        Threshold of the compressor, in dB.
    ratio : float, default 4.0
        Compression ratio (4 = 4:1).

    Returns
    -------
    numpy.ndarray
        The output levels, in dB.

    Examples
    --------
    >>> al.compressor_curve(np.array([-12, -30]), -20, 4)
    array([-18., -30.])
    """
    levels = np.asarray(levels_db, dtype=float)
    return np.where(levels <= threshold_db, levels,
                    threshold_db + (levels - threshold_db) / ratio)
