"""Audio features: Mel, MFCC, chroma and hand-crafted descriptors.

Mel spectrograms and filter banks, MFCC (also with deltas), chroma and chord
recognition, plus the time and spectral features used by the classifier.
"""

import numpy as np
import sys
if sys.platform == "emscripten":
    from . import analysis as librosa
else:
    import librosa
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .plotting import _autoshow
from .constants import NOTE_NAMES, SAMPLE_RATE
from .measures import rms, zero_crossing_rate


def mel_spectrogram(signal, sr, n_mels=64, n_fft=1024, hop=512):
    """Mel spectrogram in decibels (reference: the maximum of the clip).

    Fixed shape ``n_mels`` times number of windows: the "image" the network
    receives.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_mels : int, default 64
        Number of Mel bands.
    n_fft : int, default 1024
        Analysis window length.
    hop : int, default 512
        Hop between windows.

    Returns
    -------
    numpy.ndarray
        The matrix (Mel bands x windows), in dB (``float32``).

    Examples
    --------
    >>> S = al.mel_spectrogram(al.load_clip(path, sr=22050), sr=22050)
    >>> print(S.shape)
    """
    mel = librosa.feature.melspectrogram(
        y=np.asarray(signal, dtype=float), sr=sr, n_mels=n_mels, n_fft=n_fft,
        hop_length=hop,
    )
    return librosa.power_to_db(mel, ref=np.max).astype(np.float32)


def stft_power(signal, sr, n_fft=1024, hop=512):
    """Power spectrogram ``|X[k, t]|^2`` and the frequencies of its rows.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_fft : int, default 1024
        Analysis window length.
    hop : int, default 512
        Hop between windows.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The frequencies in Hz (513 values with ``n_fft=1024``) and the power
        matrix (frequencies x windows).

    Examples
    --------
    >>> f, P = al.stft_power(y, 22050)
    >>> print(P.shape)
    """
    X = librosa.stft(np.asarray(signal, dtype=float), n_fft=n_fft, hop_length=hop)
    return librosa.fft_frequencies(sr=sr, n_fft=n_fft), np.abs(X) ** 2


def mel_filterbank(sr, n_mels=64, n_fft=1024, htk=False, norm="slaney"):
    """The Mel filter bank: one row per band, one column per FFT bin.

    The matrix to multiply by the power spectrogram: ``B @ P`` gives the Mel
    bands. The default convention is Slaney (``htk=False``), as in librosa.

    Parameters
    ----------
    sr : int
        The sampling rate in Hz.
    n_mels : int, default 64
        Number of Mel bands.
    n_fft : int, default 1024
        Analysis window length.
    htk : bool, default False
        Use the HTK Mel formula instead of the Slaney one.
    norm : str or None, default "slaney"
        Area normalisation of the triangles.

    Returns
    -------
    numpy.ndarray
        The matrix (Mel bands x FFT bins).

    Examples
    --------
    >>> B = al.mel_filterbank(22050, n_mels=6, n_fft=1024)
    >>> print(B.shape)     # (6, 513)
    """
    return librosa.filters.mel(sr=sr, n_fft=n_fft, n_mels=n_mels, htk=htk, norm=norm)


def mel_frequencies(n_mels=64, sr=SAMPLE_RATE, fmin=0.0, fmax=None):
    """The centre frequencies of the Mel bands, in Hz.

    Returns ``n_mels + 2`` values (the two edges included), as librosa does.

    Parameters
    ----------
    n_mels : int, default 64
        Number of Mel bands.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    fmin : float, default 0.0
        Lowest frequency of the bank.
    fmax : float or None
        Highest frequency; with None, ``sr / 2``.

    Returns
    -------
    numpy.ndarray
        The frequencies in Hz.

    Examples
    --------
    >>> f = al.mel_frequencies(12, 22050)
    >>> print(int((f < 1000).sum()), "bande sotto 1 kHz")
    """
    return librosa.mel_frequencies(
        n_mels=n_mels, fmin=fmin, fmax=sr / 2 if fmax is None else fmax, htk=False
    )


def log_mel(signal, sr, n_mels=64, n_fft=1024, hop=512, ref=1.0, top_db=80):
    """Log-Mel spectrogram in decibels, with a fixed reference.

    The fixed reference (``ref=1.0``) keeps the levels comparable between
    clips; ``top_db`` sets the floor, 80 dB below the maximum of the matrix.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_mels : int, default 64
        Number of Mel bands.
    n_fft : int, default 1024
        Analysis window length.
    hop : int, default 512
        Hop between windows.
    ref : float, default 1.0
        Reference of the decibel scale.
    top_db : float, default 80
        Dynamic range kept below the maximum.

    Returns
    -------
    numpy.ndarray
        The matrix (Mel bands x windows), in dB.

    Examples
    --------
    >>> S = al.log_mel(y, 22050)
    >>> print(S.shape, S.min().round(1), S.max().round(1))
    """
    _, power = stft_power(signal, sr, n_fft=n_fft, hop=hop)
    bands = mel_filterbank(sr, n_mels=n_mels, n_fft=n_fft) @ power
    return librosa.power_to_db(bands, ref=ref, top_db=top_db)


def mfcc_matrix(signal, sr, n_mfcc=13, n_mels=64, n_fft=1024, hop=512):
    """MFCC matrix (coefficients x frames) from the log-Mel spectrogram.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_mfcc : int, default 13
        Number of coefficients kept.
    n_mels : int, default 64
        Number of Mel bands.
    n_fft : int, default 1024
        Analysis window length.
    hop : int, default 512
        Hop between windows.

    Returns
    -------
    numpy.ndarray
        The matrix (coefficients x frames); row 0 is the overall energy.

    Examples
    --------
    >>> C = al.mfcc_matrix(y, 22050)
    >>> print(C.shape)
    """
    return librosa.feature.mfcc(
        S=log_mel(signal, sr, n_mels=n_mels, n_fft=n_fft, hop=hop), n_mfcc=n_mfcc
    )


def delta(coeffs, width=9):
    """First derivative of the coefficients along time: the delta features.

    Parameters
    ----------
    coeffs : numpy.ndarray
        The matrix (coefficients x frames).
    width : int, default 9
        Number of frames of the regression window (odd).

    Returns
    -------
    numpy.ndarray
        The deltas, same shape as the input.

    Examples
    --------
    >>> D = al.delta(al.mfcc_matrix(y, 22050))
    """
    return librosa.feature.delta(np.asarray(coeffs, dtype=float), width=width)


def add_noise(signal, snr_db=10.0, seed=0):
    """Add white noise at a chosen signal-to-noise ratio.

    Parameters
    ----------
    signal : numpy.ndarray
        The clean signal.
    snr_db : float, default 10.0
        Signal-to-noise ratio, in dB.
    seed : int, default 0
        Seed of the noise generator.

    Returns
    -------
    numpy.ndarray
        The noisy signal, same length as the input.

    Examples
    --------
    >>> rumoroso = al.add_noise(y, snr_db=10)
    """
    x = np.asarray(signal, dtype=float)
    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(len(x))
    level = np.sqrt(np.mean(x ** 2)) * 10 ** (-snr_db / 20)
    noise *= level / max(np.sqrt(np.mean(noise ** 2)), 1e-12)
    return x + noise


def chroma_profile(signal, sr, hop=512):
    """Average chroma profile: twelve pitch classes, one number each.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    hop : int, default 512
        Hop between windows.

    Returns
    -------
    numpy.ndarray
        The twelve values (C, C#, D, ...), averaged over time.

    Examples
    --------
    >>> profilo = al.chroma_profile(accordo, 22050)
    >>> print(al.recognize_chord(profilo))
    """
    chroma = librosa.feature.chroma_stft(y=np.asarray(signal, dtype=float), sr=sr,
                                        hop_length=hop)
    return chroma.mean(axis=1)


def plot_mel_filterbank(sr, n_mels=12, n_fft=2048, up_to=None,
                        title="Banchi di filtri Mel"):
    """The Mel filter banks plotted with Plotly: how the spectrum is folded to
    the Mel scale.

    Parameters
    ----------
    sr : int
        The sampling rate in Hz.
    n_mels : int, default 12
        Number of banks.
    n_fft : int, default 2048
        FFT length the banks refer to.
    up_to : float or None, default None
        Upper limit of the frequency axis, in Hz.
    title : str, default "Banchi di filtri Mel"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_mel_filterbank(al.SAMPLE_RATE, n_mels=16)
    """
    banks = librosa.filters.mel(sr=sr, n_fft=n_fft, n_mels=n_mels)
    freq = np.linspace(0, sr / 2, banks.shape[1])
    fig = go.Figure()
    for i in range(banks.shape[0]):
        fig.add_trace(
            go.Scatter(
                x=freq,
                y=banks[i],
                mode="lines",
                line=dict(width=1.2),
                showlegend=False,
                hovertemplate=f"banco {i + 1} | %{{x:.0f}} Hz<extra></extra>",
            )
        )
    if up_to:
        fig.update_xaxes(range=[0, up_to])
    fig.update_layout(
        title=title, xaxis_title="frequenza [Hz]", yaxis_title="peso", height=380
    )
    return fig


def plot_mfcc(signal, sr, n_mfcc=13, n_fft=2048, hop=None, with_delta=False,
              columns=None, title="MFCC nel tempo"):
    """The MFCC coefficients as a time-coefficient heat map, Plotly style.

    With ``with_delta=True`` the figure has three stacked panels: MFCC, delta
    and delta-delta, on the same time axis. It accepts a single signal, a pair
    (name, signal) or a list of pairs: with several signals you get a grid,
    one panel per signal (with ``columns`` the number of columns is fixed).

    Parameters
    ----------
    signal : ndarray or (str, ndarray) or list of pairs
        The signal(s) to analyse, with their names (used as titles).
    sr : int
        The sampling rate in Hz.
    n_mfcc : int, default 13
        Number of coefficients.
    n_fft : int, default 2048
        Analysis window length.
    hop : int or None, default None
        Hop between windows; when absent, one quarter of n_fft.
    with_delta : bool, default False
        If True, also show delta and delta-delta in two panels below (single
        signal only).
    columns : int or None, default None
        Number of columns of the grid when there is more than one signal.
    title : str, default "MFCC nel tempo"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "speech1.wav")
    >>> al.plot_mfcc(signal, sr, with_delta=True)
    >>> al.plot_mfcc([("flauto", ya), ("archi", yb)], al.SAMPLE_RATE, columns=1)
    """
    if isinstance(signal, tuple) and isinstance(signal[0], str):
        versions = [signal]
    elif isinstance(signal, list):
        versions = list(signal)
    else:
        versions = [("segnale", signal)]
    hop = hop or n_fft // 4

    def _compute(y):
        return librosa.feature.mfcc(y=np.asarray(y, dtype=float), sr=sr, n_mfcc=n_mfcc,
                                    n_fft=n_fft, hop_length=hop)

    if len(versions) == 1:
        mfcc = _compute(versions[0][1])
        times = np.arange(mfcc.shape[1]) * hop / sr
        if not with_delta:
            fig = go.Figure(go.Heatmap(x=times, y=np.arange(1, n_mfcc + 1), z=mfcc,
                                       colorscale="RdBu", zmid=0.0,
                                       colorbar=dict(title="valore")))
            fig.update_yaxes(autorange="reversed", dtick=max(1, n_mfcc // 12),
                             title_text="coefficiente")
            fig.update_layout(title=title, xaxis_title="tempo [s]", height=420)
            return fig
        d1 = librosa.feature.delta(mfcc)
        d2 = librosa.feature.delta(mfcc, order=2)
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                            subplot_titles=("MFCC (statici)",
                                            "MFCC delta (velocità di cambiamento)",
                                            "MFCC delta-delta (accelerazione)"))
        for r, data in enumerate((mfcc, d1, d2), start=1):
            fig.add_trace(go.Heatmap(x=times, y=np.arange(1, n_mfcc + 1), z=data,
                                     colorscale="RdBu", zmid=0, showscale=(r == 3),
                                     colorbar=dict(title="valore")), row=r, col=1)
            fig.update_yaxes(autorange="reversed", title_text="coeff.", row=r, col=1)
        fig.update_xaxes(title_text="tempo [s]", row=3, col=1)
        fig.update_layout(height=640, title=title)
        return fig

    if with_delta:
        raise ValueError("with_delta vale solo per un segnale singolo.")
    columns = columns or len(versions)
    rows = -(-len(versions) // columns)
    fig = make_subplots(rows=rows, cols=columns,
                        subplot_titles=[name for name, _ in versions]
                        + [""] * (rows * columns - len(versions)))
    for k, (name, y) in enumerate(versions):
        mfcc = _compute(y)
        times = np.arange(mfcc.shape[1]) * hop / sr
        r, c = k // columns + 1, k % columns + 1
        fig.add_trace(go.Heatmap(x=times, y=np.arange(1, n_mfcc + 1), z=mfcc,
                                 colorscale="RdBu", zmid=0.0,
                                 showscale=(k == len(versions) - 1),
                                 colorbar=dict(title="valore")), row=r, col=c)
        fig.update_yaxes(autorange="reversed", title_text="coeff.", row=r, col=c)
        fig.update_xaxes(title_text="tempo [s]", row=r, col=c)
    for k in range(len(versions), rows * columns):
        fig.update_xaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
        fig.update_yaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
    fig.update_layout(height=260 * rows, title=title)
    return fig


def plot_chroma(signal, sr, hop=512, with_means=False, method="stft",
                title="Chroma: le dodici classi di altezza"):
    """The chroma as a time-pitch-class heat map, Plotly style.

    With ``with_means=True`` it adds the average profile per class below;
    ``method`` chooses the chroma estimate ("stft" or "cqt").

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    hop : int, default 512
        Hop between windows, in samples.
    with_means : bool, default False
        If True, also show the per-class means in a bar panel.
    method : str, default "stft"
        "stft" or "cqt".
    title : str, default "Chroma: le dodici classi di altezza"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "C-major-scale.wav")
    >>> al.plot_chroma(signal, sr, method="cqt", with_means=True)
    """
    signal = np.asarray(signal, dtype=float)
    if method == "cqt":
        chroma = librosa.feature.chroma_cqt(y=signal, sr=sr, hop_length=hop)
    else:
        chroma = librosa.feature.chroma_stft(y=signal, sr=sr, hop_length=hop)
    names = [
        "do",
        "do#",
        "re",
        "re#",
        "mi",
        "fa",
        "fa#",
        "sol",
        "sol#",
        "la",
        "la#",
        "si",
    ]
    times = np.arange(chroma.shape[1]) * hop / sr
    if not with_means:
        fig = go.Figure(
            go.Heatmap(
                x=times,
                y=names,
                z=chroma,
                colorscale="Viridis",
                colorbar=dict(title="energia"),
            )
        )
        fig.update_layout(title=title, xaxis_title="tempo [s]", height=420)
        return fig
    fig = make_subplots(
        rows=2,
        cols=1,
        row_heights=[0.65, 0.35],
        subplot_titles=("Chroma nel tempo", "Chroma medio: le note che compaiono"),
    )
    fig.add_trace(
        go.Heatmap(
            x=times,
            y=names,
            z=chroma,
            colorscale="Viridis",
            colorbar=dict(title="energia"),
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Bar(x=names, y=chroma.mean(axis=1), marker_color="#1769C2"), row=2, col=1
    )
    fig.update_layout(height=560, title=title, showlegend=False)
    return fig


def time_features(signal, sr=SAMPLE_RATE):
    """Two numbers from the time domain: RMS and zero crossings per second.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The vector [RMS, crossings per second].

    Examples
    --------
    >>> print(al.time_features(al.synthetic_timbre("percussioni"), 22050))
    """
    return np.array([float(rms(signal)), float(zero_crossing_rate(signal, sr))])


def spectral_features(signal, sr=SAMPLE_RATE):
    """Four numbers describing the shape of the spectrum: centroid, bandwidth,
    flatness and rolloff, averaged over time.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The vector [centroid, bandwidth, flatness, rolloff].

    Examples
    --------
    >>> print(al.spectral_features(al.synthetic_timbre("archi"), 22050))
    """
    centroid = float(np.mean(librosa.feature.spectral_centroid(y=signal, sr=sr)))
    bandwidth = float(np.mean(librosa.feature.spectral_bandwidth(y=signal, sr=sr)))
    flatness = float(np.mean(librosa.feature.spectral_flatness(y=signal)))
    rolloff = float(np.mean(librosa.feature.spectral_rolloff(y=signal, sr=sr)))
    return np.array([centroid, bandwidth, flatness, rolloff])


def mfcc_features(signal, sr=SAMPLE_RATE, n_mfcc=13):
    """The vector of MFCCs averaged over time: the aggregation used by the
    classifier.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    n_mfcc : int, default 13
        Number of coefficients.

    Returns
    -------
    numpy.ndarray
        The vector of the mean coefficients.

    Examples
    --------
    >>> v = al.mfcc_features(al.synthetic_timbre("clarinetto", midi_note=64), 22050)
    """
    return librosa.feature.mfcc(
        y=np.asarray(signal, dtype=float), sr=sr, n_mfcc=n_mfcc
    ).mean(axis=1)


def all_features(signal, sr=SAMPLE_RATE, n_mfcc=13):
    """All the features together: time, spectral and MFCC concatenated.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    n_mfcc : int, default 13
        Number of MFCC coefficients.

    Returns
    -------
    numpy.ndarray
        The vector [time, spectral, MFCC] (19 numbers with the defaults).

    Examples
    --------
    >>> print(len(al.all_features(al.synthetic_timbre("archi"), 22050)))
    """
    return np.concatenate(
        [time_features(signal, sr), spectral_features(signal, sr),
         mfcc_features(signal, sr, n_mfcc)]
    )


def chord_templates():
    """The 24 chord templates: 12 major and 12 minor, as binary vectors on the
    twelve pitch classes (1 on the notes of the chord, 0 elsewhere).

    Returns
    -------
    dict
        Chord name (for example "C maggiore") and 12-component vector.

    Examples
    --------
    >>> templates = al.chord_templates()
    >>> print(list(templates)[:2])
    """
    templates = {}
    for root in range(12):
        for mode, intervals in (("maggiore", (0, 4, 7)), ("minore", (0, 3, 7))):
            v = np.zeros(12)
            for interval in intervals:
                v[(root + interval) % 12] = 1
            templates[f"{NOTE_NAMES[root]} {mode}"] = v
    return templates


def recognize_chord(chroma_profile):
    """The chord most similar to a chroma profile, by cosine similarity with the
    templates.

    Parameters
    ----------
    chroma_profile : numpy.ndarray
        The 12-component profile (for example the mean of a chromagram).

    Returns
    -------
    (str, float)
        The name of the recognised chord and the cosine similarity.

    Examples
    --------
    >>> chord = al.synthetic_chord([60, 64, 67], seed=2)
    >>> chroma = librosa.feature.chroma_stft(y=chord, sr=22050).mean(axis=1)
    >>> print(al.recognize_chord(chroma))
    """
    templates = chord_templates()
    v = np.asarray(chroma_profile, dtype=float)
    v = v / (np.linalg.norm(v) + 1e-9)
    best, best_similarity = None, -1.0
    for name, t in templates.items():
        similarity = float(np.dot(v, t / (np.linalg.norm(t) + 1e-9)))
        if similarity > best_similarity:
            best, best_similarity = name, similarity
    return best, best_similarity


plot_mel_filterbank = _autoshow(plot_mel_filterbank)
plot_mfcc = _autoshow(plot_mfcc)
plot_chroma = _autoshow(plot_chroma)
