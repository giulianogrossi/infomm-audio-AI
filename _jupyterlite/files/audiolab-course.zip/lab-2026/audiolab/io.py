"""Reading, describing and listening to audio files.

Functions to load audio files as NumPy arrays, read their technical details,
estimate sizes and durations, and build the playback widgets used in the labs.
"""

import pathlib

import numpy as np
import soundfile as sf
import sys
if sys.platform == "emscripten":
    from . import analysis as librosa
else:
    import librosa
from IPython.display import Audio, display, Markdown

from .constants import SAMPLE_RATE
from .measures import peak_rms, to_db


def load_audio(path, mono=True, sr=None, seconds=None):
    """Load an audio file and return the signal and its sampling rate.

    Samples are returned as ``float32``. With ``mono=True`` a multi-channel file
    is reduced to mono by averaging the channels; with ``mono=False`` the
    channels are kept in a matrix (mono files become a single column). With
    ``sr`` the signal is resampled to that rate (handy to work at 22050 Hz in
    lesson 2); with ``seconds`` only the beginning of the file is read.

    Parameters
    ----------
    path : str or pathlib.Path
        Path of the audio file.
    mono : bool, default True
        If True, reduce a multi-channel file to mono by averaging the channels;
        with False keep the channels in a matrix (mono files stay a column).
    sr : int or None, default None
        If given, resample the signal to this rate in Hz.
    seconds : float or None, default None
        If given, read only the first ``seconds`` seconds.

    Returns
    -------
    (numpy.ndarray, int)
        The signal and its sampling rate in Hz.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Flute_C4.wav", sr=22050)
    >>> print(sr, "Hz,", round(al.duration_seconds(signal, sr), 2), "s")
    >>> voice, sr = al.load_audio(al.AUDIO_DIR / "speech1.wav", seconds=3)
    """
    signal, file_sr = sf.read(path, dtype="float32", always_2d=True)
    if seconds is not None:
        signal = signal[: round(seconds * file_sr)]
    if mono:
        signal = signal.mean(axis=1)
    if sr is not None and int(sr) != file_sr:
        if signal.ndim == 1:
            signal = librosa.resample(
                np.asarray(signal, dtype=float), orig_sr=file_sr, target_sr=int(sr)
            )
        else:
            signal = np.stack(
                [
                    librosa.resample(
                        np.asarray(signal[:, c], dtype=float),
                        orig_sr=file_sr,
                        target_sr=int(sr),
                    )
                    for c in range(signal.shape[1])
                ],
                axis=1,
            )
        signal = np.asarray(signal, dtype=np.float32)
        file_sr = int(sr)
    return signal, file_sr


def load_channels(path):
    """Load a file keeping the channels separate.

    The signal has one column per channel; a mono file becomes a single column.

    Parameters
    ----------
    path : str or pathlib.Path
        Path of the audio file.

    Returns
    -------
    (numpy.ndarray, int)
        The two-dimensional signal (samples x channels) and the rate in Hz.

    Examples
    --------
    >>> signal, sr = al.load_channels(al.AUDIO_DIR / "Guitar_C4.wav")
    >>> print(signal.shape)   # (samples, 2)
    """
    signal, file_sr = sf.read(path, dtype="float32")
    if signal.ndim == 1:
        signal = signal[:, None]
    return signal, file_sr


def file_info(path):
    """Read the data sheet of a file without loading its samples.

    Parameters
    ----------
    path : str or pathlib.Path
        Path of the audio file.

    Returns
    -------
    dict
        Dictionary with the keys ``nome``, ``durata_s``, ``frequenza_hz``,
        ``canali``, ``bit`` (None for non-PCM formats) and ``formato``.

    Examples
    --------
    >>> sheet = al.file_info(al.AUDIO_DIR / "Piano_C4.wav")
    >>> for key, value in sheet.items():
    ...     print(f"{key:14s} {value}")
    """
    info = sf.info(path)
    return {
        "nome": pathlib.Path(path).name,
        "durata_s": round(info.duration, 3),
        "frequenza_hz": info.samplerate,
        "canali": info.channels,
        "bit": (
            None if "PCM" not in info.subtype else int(info.subtype.replace("PCM_", ""))
        ),
        "formato": info.format,
    }


def size_mb(sr, bits, channels, seconds):
    """Size of an uncompressed audio file from its parameters.

    Parameters
    ----------
    sr : int
        Sampling rate in Hz.
    bits : int
        Bit depth per sample.
    channels : int
        Number of channels.
    seconds : float
        Duration in seconds.

    Returns
    -------
    float
        The size in megabytes (1 MB = 1024 squared bytes).

    Examples
    --------
    >>> print(f"{al.size_mb(44100, 16, 2, 180):.0f} MB per 3 minuti di stereo")
    """
    return sr * (bits / 8) * channels * seconds / 1024**2


def duration_seconds(signal, sr):
    """Duration in seconds of a signal already in memory.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        Its sampling rate in Hz.

    Returns
    -------
    float
        The duration in seconds.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Piano_C4.wav")
    >>> print(round(al.duration_seconds(signal, sr), 3), "s")
    """
    return len(signal) / sr


def listen(signal, sr):
    """Build the audio player for a cell.

    Use it as the last expression of the cell, or inside ``display(...)``.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal to listen to.
    sr : int
        The sampling rate in Hz.

    Returns
    -------
    IPython.display.Audio
        An audio player to show in the cell.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Guitar_C4.wav")
    >>> al.listen(signal, sr)
    """
    return Audio(np.asarray(signal, dtype=float), rate=sr)


def safe_audio(signal, sr=SAMPLE_RATE, normalize=True):
    """Like ``listen``, but attenuates the signal when its peak exceeds 1.

    With ``normalize=False`` the signal is played at its digital level, without
    normalisation: useful for comparisons at equal loudness (it requires finite
    samples between -1 and 1, otherwise it raises an error).

    Parameters
    ----------
    signal : numpy.ndarray
        The signal to listen to.
    sr : int, default SAMPLE_RATE
        The sampling rate in Hz.
    normalize : bool, default True
        With False respect the digital level (no normalisation).

    Returns
    -------
    IPython.display.Audio
        The audio player.

    Examples
    --------
    >>> total = al.sine(440, 0.5) + al.sine(660, 0.5)   # peak above 1
    >>> al.safe_audio(total)
    """
    signal = np.asarray(signal, dtype=float)
    if not normalize:
        if not np.all(np.isfinite(signal)) or np.max(np.abs(signal)) > 1:
            raise ValueError(
                "Per l'ascolto a livello digitale servono campioni finiti compresi fra -1 e 1."
            )
        return Audio(signal, rate=sr, normalize=False)
    peak = np.max(np.abs(signal)) if signal.size else 0
    return Audio(signal / max(1.0, peak), rate=sr)


def compare_audio(samples, sr=SAMPLE_RATE):
    """Comparative listening: same gain for every version, measures printed.

    The gain is applied to all the versions (so level differences do not
    mislead), the measures are printed and the players are shown one after the
    other.

    Parameters
    ----------
    samples : list of (str, numpy.ndarray) pairs
        The versions to compare.
    sr : int, default SAMPLE_RATE
        Sampling rate in Hz.

    Returns
    -------
    None
        Prints the measures and shows the players in the cell.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Guitar_C4.wav")
    >>> al.compare_audio([("originale", signal), ("8 bit", al.quantize(signal, 8))], sr)
    """
    for name, signal in samples:
        if not np.size(signal) or not np.all(np.isfinite(signal)):
            raise ValueError(f"Segnale non valido: {name}")
    maximum = max(peak_rms(signal)[0] for _, signal in samples)
    factor = min(1.0, 0.8 / max(maximum, 1e-12))
    print(f"Guadagno comune per l'ascolto: {to_db(factor):.1f} dB")
    for name, signal in samples:
        peak, level = peak_rms(signal)
        display(
            Markdown(
                f"**{name}** — {len(signal)/sr:.2f} s; "
                f"picco {peak:.3f}; RMS {level:.4f}"
            )
        )
        data = (signal.T if signal.ndim == 2 else signal) * factor
        display(Audio(data, rate=sr, normalize=False))


def save_audio(path, signal, sr=SAMPLE_RATE, subtype="PCM_16"):
    """Write a signal to a WAV file.

    Parameters
    ----------
    path : str or pathlib.Path
        Destination file (the folder must exist).
    signal : numpy.ndarray
        The signal, mono or multichannel.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    subtype : str, default "PCM_16"
        Soundfile subtype: "PCM_16", "PCM_24", "FLOAT", ...

    Returns
    -------
    pathlib.Path
        The path written.

    Examples
    --------
    >>> al.save_audio(al.OUTPUT_DIR / "esempio.wav", voce, sr)
    """
    path = pathlib.Path(path)
    sf.write(path, np.asarray(signal, dtype=float), sr, subtype=subtype)
    return path
