"""Levels, levels in decibels and basic signal measurements.

Functions to compute the RMS value, convert amplitudes to decibels, measure
crest factor, zero crossings, estimated frequency and signal-to-noise ratio,
and convert pressures and intensities to their levels.
"""

import numpy as np

from .constants import P_REF, I_REF


def rms(signal):
    """Root mean square of the signal (its "average loudness").

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.

    Returns
    -------
    float
        The root mean square value.

    Examples
    --------
    >>> tone = al.sine(440, 0.5)
    >>> print(f"RMS {al.rms(tone):.3f}")
    """
    return float(np.sqrt(np.mean(np.asarray(signal, dtype=float) ** 2)))


def to_db(amplitude, floor=1e-12):
    """Convert an amplitude (or a ratio of amplitudes) to decibels: 20 log10.

    Parameters
    ----------
    amplitude : float or numpy.ndarray
        The amplitude (or amplitudes).
    floor : float, default 1e-12
        Lower bound applied before the logarithm, to avoid ``log10(0)``.

    Returns
    -------
    float or numpy.ndarray
        The value in decibels (same shape as the input).

    Examples
    --------
    >>> print(round(float(al.to_db(10)), 1), "dB")     # +20
    >>> print(round(float(al.to_db(0.1)), 1), "dB")    # -20
    """
    return 20 * np.log10(np.maximum(np.asarray(amplitude, dtype=float), floor))


def to_dbfs(signal):
    """RMS level of the signal relative to full scale.

    Full scale (0 dBFS) corresponds to a square wave that uses the whole
    available range.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.

    Returns
    -------
    float
        The level in dBFS (normally negative; below full scale).

    Examples
    --------
    >>> tone = al.sine(440, 0.5)
    >>> print(f"{al.to_dbfs(tone):.1f} dBFS")
    """
    return float(to_db(rms(signal)))


def crest_factor(signal):
    """Difference between peak and RMS value, in decibels.

    Tells how impulsive the sound is (high for sharp hits, low for continuous
    sounds).

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.

    Returns
    -------
    float
        The crest factor in decibels.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Piano_C4.wav")
    >>> print(f"cresta {al.crest_factor(signal):.1f} dB (una nota sostenuta: circa 18)")
    """
    signal = np.asarray(signal, dtype=float)
    return float(to_db(np.max(np.abs(signal)) + 1e-12) - to_dbfs(signal))


def zero_crossing_rate(signal, sr):
    """How many zero crossings happen in one second.

    For a pure tone it is about twice the frequency.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.

    Returns
    -------
    float
        The number of crossings per second.

    Examples
    --------
    >>> tone = al.sine(440, 0.5)
    >>> print(f"{al.zero_crossing_rate(tone, al.SAMPLE_RATE):.0f} attraversamenti al secondo")
    """
    signal = np.asarray(signal, dtype=float)
    changes = np.sum(np.diff(np.signbit(signal)))
    return float(changes / (len(signal) / sr))


def estimate_frequency(signal, sr):
    """Frequency of a tone estimated from zero crossings (half their rate).

    The estimate is approximated: it counts whole oscillations and does not
    know the phase at the beginning and at the end.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (one tone at a time).
    sr : int
        The sampling rate in Hz.

    Returns
    -------
    float
        The estimated frequency in Hz.

    Examples
    --------
    >>> tone = al.sine(1000, 1.0)
    >>> print(f"{al.estimate_frequency(tone, al.SAMPLE_RATE):.0f} Hz")
    """
    return zero_crossing_rate(signal, sr) / 2


def snr(original, reconstructed):
    """Distance between the signal and the added noise (or the error), in dB.

    Tells how far the noise sits below the signal.

    Parameters
    ----------
    original : numpy.ndarray
        The reference signal.
    reconstructed : numpy.ndarray
        The version compared, of the same length.

    Returns
    -------
    float
        The signal-to-noise ratio in decibels.

    Examples
    --------
    >>> tone = al.sine(440, 0.5)
    >>> rough = al.quantize(tone, 6)
    >>> print(f"SNR {al.snr(tone, rough):.1f} dB")
    """
    original = np.asarray(original, dtype=float)
    error = np.asarray(reconstructed, dtype=float) - original
    return float(
        to_db(np.sqrt(np.mean(original**2)) / (np.sqrt(np.mean(error**2)) + 1e-12))
    )


def db_pressure(p_rms, p_ref=P_REF):
    """Sound pressure level of an RMS pressure: 20 log10(p / 20 uPa).

    Parameters
    ----------
    p_rms : float or numpy.ndarray
        RMS pressure, in pascal.
    p_ref : float, default 20 uPa
        The reference pressure.

    Returns
    -------
    float or numpy.ndarray
        The level in dB SPL.

    Examples
    --------
    >>> p = 0.2   # RMS pascal
    >>> print(f"{float(al.db_pressure(p)):.1f} dB SPL")
    """
    p_rms = np.asarray(p_rms, dtype=float)
    return 20 * np.log10(np.maximum(p_rms, np.finfo(float).tiny) / p_ref)


def db_intensity(intensity, i_ref=I_REF):
    """Level of an intensity (or a power) relative to 1 pW/m2: 10 log10(I / I0).

    Parameters
    ----------
    intensity : float or numpy.ndarray
        The intensity, in W/m2.
    i_ref : float, default 1 pW/m2
        The reference intensity.

    Returns
    -------
    float or numpy.ndarray
        The level in decibels.

    Examples
    --------
    >>> i = 1e-6   # watt per square metre
    >>> print(f"{float(al.db_intensity(i)):.1f} dB")
    """
    intensity = np.asarray(intensity, dtype=float)
    return 10 * np.log10(np.maximum(intensity, np.finfo(float).tiny) / i_ref)


def peak_rms(signal):
    """The two basic level measures: peak and RMS value.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.

    Returns
    -------
    (float, float)
        The pair (peak, RMS).

    Examples
    --------
    >>> peak, level = al.peak_rms(al.sine(440, 0.5))
    >>> print(peak, level)
    """
    signal = np.asarray(signal, dtype=np.float64)
    return float(np.max(np.abs(signal))), float(np.sqrt(np.mean(signal * signal)))


def block_rms(signal, block):
    """RMS value computed on non-overlapping blocks.

    Used to follow the level envelope with a declared resolution: for example
    10 ms (10 periods of a 1 kHz tone).

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    block : int
        Block length, in samples (for example ``round(0.01 * sr)``).

    Returns
    -------
    numpy.ndarray
        One RMS value per block.

    Examples
    --------
    >>> block = round(0.01 * sr)
    >>> envelope = al.block_rms(probe, block)
    """
    signal = np.asarray(signal)
    return np.sqrt(
        np.mean(signal[: len(signal) // block * block].reshape(-1, block) ** 2, axis=1)
    )
