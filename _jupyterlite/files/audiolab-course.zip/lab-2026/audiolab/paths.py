"""Well-known directories of the course workspace.

The workspace layout is::

    InfoMM-local/
    ├── lab-2026/            notebooks and this library
    ├── dispensa-2026/       book sources
    ├── slides-2026/         slide decks
    ├── audio-file/          audio samples used by the lessons
    └── datasets/            external datasets (UrbanSound8K, ESC-50)
"""

from pathlib import Path

#: Root of the course workspace (``InfoMM-local``).
PROJECT_ROOT = Path(__file__).resolve().parents[2]

#: Directory of the labs.
LAB_DIR = PROJECT_ROOT / "lab-2026"

#: Directory of the materials precomputed by the labs.
MATERIALS_DIR = LAB_DIR / "materiali"

#: Directory of the audio samples used by the lessons.
AUDIO_DIR = PROJECT_ROOT / "audio-file"

#: Directory of the external datasets.
DATASETS_DIR = PROJECT_ROOT / "datasets"


def project_root() -> Path:
    """Return the root directory of the course workspace.

    Returns
    -------
    pathlib.Path
        The ``InfoMM-local`` directory.

    Examples
    --------
    >>> import audiolab as al
    >>> al.project_root().name
    'InfoMM-local'
    """
    return PROJECT_ROOT
