"""Generic figures: waveforms, channels and overlaid curves.

All the functions in this module build a Plotly figure, show it in the notebook
and return it; with ``show=False`` they only return it.
"""

import functools
import inspect

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def _display_figure(figure, show=True):
    """Show the figure in a notebook (default) and return it."""
    if show:
        try:
            from IPython import get_ipython
            from IPython.display import display

            if get_ipython() is not None:
                display(figure)
        except Exception:  # pragma: no cover - fuori da Jupyter non serve
            pass
    return figure


def _autoshow(func):
    """Display the figure returned by a plot function, unless ``show=False``."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        show = kwargs.pop("show", True)
        figure = func(*args, **kwargs)
        if show:
            _display_figure(figure)
            return None
        return figure

    parametri = list(inspect.signature(func).parameters.values())
    parametri.append(
        inspect.Parameter("show", inspect.Parameter.KEYWORD_ONLY, default=True,
                          annotation=bool)
    )
    wrapper.__signature__ = inspect.Signature(parametri)
    return wrapper


def _figure(title, height=320):
    """Internal: a Plotly figure with the common course settings (white theme,
    margins, legend at the bottom)."""
    figure = go.Figure()
    figure.update_layout(
        template="plotly_white",
        height=height,
        title=title,
        margin=dict(l=60, r=20, t=50, b=40),
        legend=dict(orientation="h", y=-0.2),
    )
    return figure


def plot_waveform(signal, sr, title="Forma d'onda", seconds=None, name="segnale"):
    """Plot the waveform with Plotly.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal to plot.
    sr : int
        The sampling rate in Hz.
    title : str, default "Forma d'onda"
        Title of the figure.
    seconds : float or None, default None
        If given, show only the first ``seconds`` seconds.
    name : str, default "segnale"
        Label of the trace in the legend.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> tone = al.sine(440, 0.05)
    >>> al.plot_waveform(tone, al.SAMPLE_RATE, "Tono a 440 Hz", seconds=0.02)
    """
    signal = np.asarray(signal)
    if seconds:
        signal = signal[: int(seconds * sr)]
    figure = _figure(title)
    figure.add_trace(
        go.Scatter(
            x=np.arange(len(signal)) / sr,
            y=signal,
            mode="lines",
            line=dict(width=1),
            name=name,
        )
    )
    figure.update_xaxes(title_text="Tempo [s]")
    figure.update_yaxes(title_text="Ampiezza")
    return figure


def plot_waveforms(signals, sr, labels=None, title="Confronto"):
    """Plot several signals overlaid in the same figure.

    Useful to compare channels, versions of the same sound or signals with
    different characteristics.

    Parameters
    ----------
    signals : list of numpy.ndarray
        The signals to compare.
    sr : int
        The shared sampling rate.
    labels : list of str or None, default None
        Trace names; when absent it uses "segnale 1", "segnale 2", ...
    title : str, default "Confronto"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_waveforms([al.sine(220, 0.02, amplitude=0.9),
    ...                    al.sine(220, 0.02, amplitude=0.09)],
    ...                   al.SAMPLE_RATE, ["0,9", "0,09"],
    ...                   "Stessa frequenza, ampiezza diversa")
    """
    labels = labels or [f"segnale {i+1}" for i in range(len(signals))]
    figure = _figure(title)
    for signal, label in zip(signals, labels):
        figure.add_trace(
            go.Scatter(
                x=np.arange(len(signal)) / sr,
                y=signal,
                mode="lines",
                line=dict(width=1),
                name=label,
            )
        )
    figure.update_xaxes(title_text="Tempo [s]")
    figure.update_yaxes(title_text="Ampiezza")
    return figure


def plot_channels(signal, sr, title="Canali del file", seconds=0.05):
    """Plot the channels of a stereo file overlaid, on a short portion.

    Parameters
    ----------
    signal : numpy.ndarray
        The two-column signal.
    sr : int
        The sampling rate in Hz.
    title : str, default "Canali del file"
        Title of the figure.
    seconds : float, default 0.05
        Duration of the portion shown, in seconds.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> signal, sr = al.load_channels(al.AUDIO_DIR / "Guitar_C4.wav")
    >>> al.plot_channels(signal, sr)
    """
    signal = np.asarray(signal)
    n = int(seconds * sr)
    figure = _figure(title)
    for i in range(signal.shape[1]):
        figure.add_trace(
            go.Scatter(
                x=np.arange(min(n, len(signal))) / sr,
                y=signal[:n, i],
                mode="lines",
                line=dict(width=1.4),
                name=f"canale {i+1}",
            )
        )
    figure.update_xaxes(title_text="Tempo [s]")
    figure.update_yaxes(title_text="Ampiezza")
    return figure


def plot_signal_rows(rows, sr, seconds=None, start=None,
                     title="I segnali, uno per riga", row_height=150):
    """Plot one or more signals, each on a row.

    Every row can contain a single trace or several overlaid traces (with a
    legend). It accepts a single signal, a row (name, signal) or (name, time,
    signal), or a list of rows; a row with several traces is written
    (name, [traces]).

    Parameters
    ----------
    rows : ndarray or row or list of rows
        The signals to plot; a row is (name, signal), (name, time, signal) or
        (name, [traces]) with traces of the same shape, without the row name.
    sr : int
        The sampling rate in Hz.
    seconds : float or None, default None
        If given, show only a portion of ``seconds`` seconds.
    start : float or None, default None
        Initial instant of the portion shown, in seconds.
    title : str, default "I segnali, uno per riga"
        Title of the figure.
    row_height : int, default 150
        Height in pixels of each row.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_signal_rows([("originale", voice), ("elaborata", voice_eq)], sr, seconds=3)
    >>> al.plot_signal_rows([("nota", note),
    ...                      ("livelli", [("inviluppo", env), ("RMS", times, rms)])], sr)
    """

    def _clip(x, y):
        y = np.asarray(y)
        if x is not None:
            x = np.asarray(x)
            if start is None and seconds is None:
                return x, y
            t0 = 0.0 if start is None else start
            mask = x >= t0
            if seconds is not None:
                mask &= x < t0 + seconds
            return x[mask], y[mask]
        i = 0 if start is None else int(round(start * sr))
        j = len(y) if seconds is None else i + int(round(seconds * sr))
        y = y[i:j]
        return (np.arange(len(y)) + i) / sr, y

    if isinstance(rows, np.ndarray):
        panels = [("segnale", rows)]
    elif isinstance(rows, tuple) and isinstance(rows[0], str):
        panels = [rows]
    else:
        panels = list(rows)
    prepared = []
    for row in panels:
        name = row[0]
        rest = row[1:]
        if len(rest) == 2:
            prepared.append((name, [(name, rest[0], rest[1])]))
        elif len(rest) == 1 and isinstance(rest[0], list):
            traces = []
            for t in rest[0]:
                if len(t) == 3:
                    traces.append((t[0], t[1], t[2]))
                else:
                    traces.append((t[0], None, t[1]))
            prepared.append((name, traces))
        else:
            prepared.append((name, [(name, None, rest[0])]))
    fig = make_subplots(
        rows=len(prepared),
        cols=1,
        shared_xaxes=True,
        subplot_titles=[name for name, _ in prepared],
    )
    for r, (_, traces) in enumerate(prepared, start=1):
        for trace_name, x, y in traces:
            xx, yy = _clip(x, y)
            fig.add_trace(
                go.Scatter(
                    x=xx,
                    y=yy,
                    mode="lines",
                    name=trace_name,
                    line=dict(width=1),
                    showlegend=len(traces) > 1,
                ),
                row=r,
                col=1,
            )
    fig.update_xaxes(title_text="Tempo [s]", row=len(prepared), col=1)
    fig.update_layout(height=row_height * len(prepared), title=title)
    return fig


def plot_curves(series, x_title=None, y_title=None, x_scale=None, y_scale=None,
                x_range=None, y_range=None, hlines=None, vlines=None,
                mode="lines", columns=None, styles=None,
                title="Curve a confronto", height=None):
    """Plot one or more curves (name, x, y), overlaid or in a grid.

    For frequency responses, filter curves and comparisons of measures. It
    accepts a single triple or a list of triples. With ``columns`` each curve
    gets its own panel; with ``mode="bars"`` the series become histograms
    (line spectra).

    Parameters
    ----------
    series : (str, ndarray, ndarray) or list of triples
        The curves: name, abscissas and ordinates.
    x_title, y_title : str or None
        Axis titles.
    x_scale, y_scale : str or None
        "log" for a logarithmic axis.
    x_range, y_range : list or None
        Axis limits (for a log axis, the real values).
    hlines : list of float or None
        Dashed horizontal lines.
    vlines : list or None
        Vertical lines: values, or pairs (value, label).
    mode : str, default "lines"
        "lines", "markers", "lines+markers" or "bars".
    columns : int or None, default None
        Number of columns of the grid; with None the curves are overlaid.
    styles : list of dict or None
        Style for each curve: items of go.Scatter, or of go.Bar with
        mode="bars".
    title : str, default "Curve a confronto"
        Title of the figure.
    height : int or None
        Height in pixels; when absent, 380 (or 320 per row in a grid).

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> from scipy import signal
    >>> sos = signal.butter(4, 800, "lowpass", fs=al.SAMPLE_RATE, output="sos")
    >>> f, gain = al.sos_response(sos)
    >>> al.plot_curves([("passa-basso 800 Hz", f[1:], gain[1:])],
    ...                x_title="Frequenza [Hz]", y_title="Guadagno [dB]",
    ...                x_scale="log", x_range=[50, 20000], hlines=[-3])
    """
    if isinstance(series, tuple) and isinstance(series[0], str):
        series = [series]
    modes = {"lines": "lines", "markers": "markers", "lines+markers": "lines+markers"}
    if mode != "bars" and mode not in modes:
        raise ValueError("modo deve essere lines, markers, lines+markers o bars.")
    if columns is None:
        fig = go.Figure()
        for j, (name, x, y) in enumerate(series):
            style = dict(styles[j]) if styles is not None else {}
            if mode == "bars":
                fig.add_trace(go.Bar(x=x, y=y, name=name, **style))
            else:
                fig.add_trace(
                    go.Scatter(x=x, y=y, mode=modes[mode], name=name, line=style)
                )
    else:
        rows = -(-len(series) // columns)
        fig = make_subplots(
            rows=rows,
            cols=columns,
            subplot_titles=[name for name, _, _ in series]
            + [""] * (rows * columns - len(series)),
        )
        for j, (name, x, y) in enumerate(series):
            r, c = j // columns + 1, j % columns + 1
            style = dict(styles[j]) if styles is not None else {}
            if mode == "bars":
                fig.add_trace(go.Bar(x=x, y=y, showlegend=False, **style), row=r, col=c)
            else:
                fig.add_trace(
                    go.Scatter(x=x, y=y, mode=modes[mode], showlegend=False, line=style),
                    row=r,
                    col=c,
                )
        for j in range(len(series), rows * columns):
            fig.update_xaxes(visible=False, row=j // columns + 1, col=j % columns + 1)
            fig.update_yaxes(visible=False, row=j // columns + 1, col=j % columns + 1)
    for yv in hlines or []:
        fig.add_hline(y=yv, line=dict(color="grey", dash="dot"))
    for item in vlines or []:
        point, label = item if isinstance(item, (tuple, list)) else (item, None)
        kw = dict(line=dict(color="grey", dash="dash"))
        if label:
            kw["annotation_text"] = label
        fig.add_vline(x=point, **kw)
    if x_scale == "log":
        fig.update_xaxes(type="log")
    if y_scale == "log":
        fig.update_yaxes(type="log")
    if x_range is not None:
        if x_scale == "log":
            fig.update_xaxes(range=[np.log10(x_range[0]), np.log10(x_range[1])])
        else:
            fig.update_xaxes(range=list(x_range))
    if y_range is not None:
        fig.update_yaxes(range=list(y_range))
    if x_title:
        fig.update_xaxes(title_text=x_title)
    if y_title:
        fig.update_yaxes(title_text=y_title)
    if height is None:
        height = 380 if columns is None else 320 * (-(-len(series) // columns))
    fig.update_layout(height=height, title=title)
    return fig


plot_waveform = _autoshow(plot_waveform)
plot_waveforms = _autoshow(plot_waveforms)
plot_channels = _autoshow(plot_channels)
plot_signal_rows = _autoshow(plot_signal_rows)
plot_curves = _autoshow(plot_curves)
