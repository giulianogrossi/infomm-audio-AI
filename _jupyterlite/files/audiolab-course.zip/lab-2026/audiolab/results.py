"""Read and explore recorded classification experiments without training a model."""
import json
from pathlib import Path
import numpy as np


def load_classification_results(path):
    """Read the versioned chapter-4 results, splits and model predictions.

    Parameters
    ----------
    path : str or pathlib.Path
        Path of the JSON exported by ``interattivo/export_results.py``.

    Returns
    -------
    dict
        Recorded experiment, including provenance and the original split order.
    """
    data = json.loads(Path(path).read_text())
    if data.get('schema_version') != 1:
        raise ValueError('Formato dei risultati non supportato.')
    count = len(data['classes'])
    for model in data['models'].values():
        for split in ('val', 'test'):
            predictions = np.asarray(model[f'{split}_predictions'])
            if len(predictions) != len(data['splits'][split]) or np.any((predictions<0)|(predictions>=count)):
                raise ValueError('Predizioni e manifest non corrispondono.')
    return data


def classification_metrics(true, predicted, n_classes=10):
    """Compute accuracy, macro-F1 and a count confusion matrix on fixed labels.

    Parameters
    ----------
    true, predicted : array_like
        One true and predicted class id per clip, in the same order.
    n_classes : int, default 10
        Number of labels, including classes without predicted examples.

    Returns
    -------
    dict
        Accuracy, macro-F1, per-class F1, and confusion counts (true rows).
        Undefined per-class F1 values are set to zero.
    """
    true, predicted = np.asarray(true), np.asarray(predicted)
    if true.ndim != 1 or true.shape != predicted.shape or not len(true):
        raise ValueError('Etichette non vuote e della stessa lunghezza richieste.')
    if np.any((true<0)|(true>=n_classes)|(predicted<0)|(predicted>=n_classes)):
        raise ValueError('Identificativo di classe non valido.')
    cm = np.zeros((n_classes,n_classes),dtype=int)
    np.add.at(cm,(true.astype(int),predicted.astype(int)),1)
    denominator = cm.sum(0)+cm.sum(1)
    f1 = np.divide(2*np.diag(cm),denominator,out=np.zeros(n_classes),where=denominator>0)
    return dict(accuracy=float(np.trace(cm)/cm.sum()),macro_f1=float(f1.mean()),f1=f1,confusion=cm)


async def load_result_clip(record, directory, base_url=None):
    """Load the original test audio associated with a recorded prediction.

    Parameters
    ----------
    record : dict
        A test-manifest record, including the exported WAV filename ``audio``.
    directory : str or pathlib.Path
        Local directory containing, or caching, the exported WAV clips.
    base_url : str or None, default None
        In Pyodide, the published directory from which to fetch a missing clip.

    Returns
    -------
    (numpy.ndarray, int)
        Original mono samples and their sampling rate, as read by load_audio.
    """
    name = record['audio']
    if Path(name).name != name or not name.endswith('.wav'):
        raise ValueError('Nome del campione non valido.')
    path = Path(directory)/name
    if not path.exists():
        if base_url is None:
            raise FileNotFoundError(path)
        from pyodide.http import pyfetch
        response = await pyfetch(base_url.rstrip('/')+'/'+name)
        if not response.ok:
            raise RuntimeError(f'Campione non disponibile: {response.status}')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(await response.bytes())
    from .io import load_audio
    return load_audio(path)
