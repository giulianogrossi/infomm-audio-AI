"""Spectrum and frequency analysis.

Spectra in linear amplitude and decibels, spectrograms (linear and Mel),
harmonic profiles and spectral slope.
"""

import numpy as np
import scipy.signal
import sys
if sys.platform == "emscripten":
    from . import analysis as librosa
else:
    import librosa
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .plotting import _autoshow


def amplitude_spectrum(signal, sr, n_fft=None, window="hann"):
    """One-sided spectrum in linear amplitude.

    Peak values corrected by the window gain, useful for quantitative
    comparisons (peaks, harmonic profiles).

    Parameters
    ----------
    signal : numpy.ndarray
        The mono signal (at least four samples).
    sr : int
        The sampling rate in Hz.
    n_fft : int or None, default None
        FFT length; when absent it uses the signal length.
    window : str, default "hann"
        Window name (from scipy.signal names).

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The frequencies in Hz and the peak amplitudes. Raises ValueError if
        the signal is too short or n_fft truncates the samples.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Piano_C4.wav")
    >>> f, amplitude = al.amplitude_spectrum(signal, sr)
    >>> print(f"picco a {f[amplitude.argmax()]:.1f} Hz")
    """
    signal = np.asarray(signal, dtype=float)
    if signal.ndim != 1 or len(signal) < 4:
        raise ValueError("Servono almeno quattro campioni mono.")
    n_fft = len(signal) if n_fft is None else int(n_fft)
    if n_fft < len(signal):
        raise ValueError("n_fft non deve troncare i campioni osservati.")
    w = scipy.signal.get_window(window, len(signal), fftbins=True)
    amplitude = np.abs(np.fft.rfft(signal * w, n=n_fft)) / w.sum()
    amplitude[1 : -1 if n_fft % 2 == 0 else None] *= 2
    return np.fft.rfftfreq(n_fft, 1 / sr), amplitude


def db_spectrum(signal, sr, n=8192, start=0.0):
    """Spectrum in decibels: 20 log10 of the amplitude, with an initial offset in seconds.

    Meant to look at the dynamics: peaks, weak harmonics, noise floor.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n : int, default 8192
        Number of samples analysed.
    start : float, default 0.0
        Initial instant of the analysis, in seconds.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The frequencies and the levels in dB.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Piano_C4.wav")
    >>> f, spectrum = al.db_spectrum(signal, sr)
    >>> print(f"massimo {spectrum.max():.1f} dB")
    """
    i = int(start * sr)
    if i < 0:
        raise ValueError("Il tempo iniziale deve essere non negativo.")
    segment = np.asarray(signal)[i : i + n]
    f, amplitude = amplitude_spectrum(segment, sr)
    return f, 20 * np.log10(np.maximum(amplitude, 1e-8))


def plot_spectrum(signal, sr, n_fft=None, window="hann", title="Spettro", up_to=None):
    """Two-panel spectrum: linear amplitude and level in decibels.

    The two readings serve different purposes: the linear one compares the
    amplitudes, the logarithmic one shows the dynamics.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_fft : int or None, default None
        FFT length.
    window : str, default "hann"
        Window name.
    title : str, default "Spettro"
        Title of the figure.
    up_to : float or None, default None
        If given, limit the frequency axis to ``up_to`` Hz.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "Piano_C4.wav")
    >>> al.plot_spectrum(signal, sr, up_to=5000)
    """
    f, amplitude = amplitude_spectrum(signal, sr, n_fft=n_fft, window=window)
    db = 20 * np.log10(np.maximum(amplitude, 1e-8))
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        subplot_titles=("Ampiezza (lineare)", "Livello [dB]"),
        vertical_spacing=0.12,
    )
    fig.add_trace(
        go.Scatter(
            x=f,
            y=amplitude,
            mode="lines",
            line=dict(width=1, color="#1769C2"),
            name="lineare",
        ),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=f, y=db, mode="lines", line=dict(width=1, color="#B8860B"), name="dB"
        ),
        row=2,
        col=1,
    )
    if up_to:
        fig.update_xaxes(range=[0, up_to])
    fig.update_xaxes(title_text="frequenza [Hz]", row=2, col=1)
    fig.update_yaxes(title_text="ampiezza", row=1, col=1)
    fig.update_yaxes(title_text="dB", row=2, col=1)
    fig.update_layout(height=520, title=title, showlegend=False)
    return fig


def plot_spectra(versions, sr, up_to=None, scale="db", columns=None, vlines=None,
                 y_range=None, title="Spettri a confronto"):
    """Spectra of one or more signals, overlaid or in a grid.

    The conventions are those of ``db_spectrum()``; with ``scale="linear"`` the
    peak amplitude of ``amplitude_spectrum()`` is used. With no ``columns`` the
    spectra are overlaid in the same figure; with a number of columns they
    become one panel per signal. It accepts a single signal, a pair or a list
    of pairs.

    Parameters
    ----------
    versions : ndarray or (str, ndarray) or list of pairs
        The signal or signals to analyse, with their names.
    sr : int
        The sampling rate in Hz.
    up_to : float or None, default None
        If given, limit the frequency axis to ``up_to`` Hz.
    scale : str, default "db"
        "db" for the level in decibels, "linear" for the peak amplitude.
    columns : int or None, default None
        Number of columns of the grid; with None the spectra are overlaid.
    vlines : list or None, default None
        Vertical reference lines, in Hz; an item can be (Hz, label).
    y_range : list or None, default None
        Limits of the vertical axis, for example [-70, 5].
    title : str, default "Spettri a confronto"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_spectra([("originale", voice), ("filtrata", voice_hp)], sr, up_to=8000)
    >>> al.plot_spectra(versions, sr, columns=3, vlines=[(261.63, "do4")])
    """
    if isinstance(versions, np.ndarray):
        versions = [("segnale", versions)]
    elif isinstance(versions, tuple) and isinstance(versions[0], str):
        versions = [versions]

    def _spectrum(y):
        y = np.asarray(y)
        if scale == "linear":
            i = int(0.5 * sr)
            return amplitude_spectrum(y[i : i + 8192], sr)
        return db_spectrum(y, sr)

    data = [(name, *_spectrum(y)) for name, y in versions]
    y_title = "Livello [dB]" if scale == "db" else "Ampiezza"
    if columns is None:
        fig = go.Figure()
        for name, f, s in data:
            visible = slice(None) if up_to is None else f <= up_to
            fig.add_trace(
                go.Scatter(x=f[visible], y=s[visible], mode="lines", name=name)
            )
        fig.update_xaxes(title_text="Frequenza [Hz]")
        fig.update_yaxes(title_text=y_title)
        height = 380
        grid = None
    else:
        rows = -(-len(data) // columns)
        fig = make_subplots(
            rows=rows,
            cols=columns,
            subplot_titles=[name for name, _, _ in data]
            + [""] * (rows * columns - len(data)),
        )
        for k, (name, f, s) in enumerate(data):
            r, c = k // columns + 1, k % columns + 1
            visible = slice(None) if up_to is None else f <= up_to
            fig.add_trace(
                go.Scatter(
                    x=f[visible],
                    y=s[visible],
                    mode="lines",
                    line=dict(width=1),
                    showlegend=False,
                ),
                row=r,
                col=c,
            )
            fig.update_xaxes(title_text="Frequenza [Hz]", row=r, col=c)
            fig.update_yaxes(title_text=y_title, row=r, col=c)
        for k in range(len(data), rows * columns):
            fig.update_xaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
            fig.update_yaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
        height = 320 * rows
        grid = (rows, columns)
    for item in vlines or []:
        point, label = item if isinstance(item, (tuple, list)) else (item, None)
        kw = dict(line=dict(color="grey", width=1))
        if label:
            kw["annotation_text"] = label
        if grid is None:
            fig.add_vline(x=point, **kw)
        else:
            rows, columns_ = grid
            for k in range(len(data)):
                fig.add_vline(x=point, row=k // columns_ + 1, col=k % columns_ + 1, **kw)
    if up_to is not None:
        fig.update_xaxes(range=[0, up_to])
    if y_range is not None:
        fig.update_yaxes(range=list(y_range))
    fig.update_layout(height=height, title=title)
    return fig


def plot_spectrograms(versions, sr, nperseg=1024, overlap=768, nfft=None, up_to=5000,
                      floor=-70, columns=2, mel=False, n_mels=80, windows=None,
                      stride=None, title="Spettrogrammi a scala comune"):
    """Grid of spectrograms with the same colour scale.

    Useful to compare several versions of the same signal without each one
    being normalised on its own. It accepts a pair (name, signal) or a list of
    pairs. With ``mel=True`` the maps are Mel spectrograms (nperseg is the FFT
    length and the hop is nperseg - overlap); every item of ``windows`` can fix
    (nperseg, overlap) of its own panel. ``stride`` lightens the figure by
    showing one frequency every ``stride[0]`` and one column every
    ``stride[1]``.

    Parameters
    ----------
    versions : (str, ndarray) or list of pairs
        The signals to plot, with their names.
    sr : int
        The sampling rate in Hz.
    nperseg : int, default 1024
        Analysis window length.
    overlap : int, default 768
        Samples overlapped between consecutive windows.
    nfft : int or None, default None
        FFT size, when different from nperseg.
    up_to : float or None, default 5000
        Upper limit of the frequency axis, in Hz (ignored with mel=True).
    floor : float, default -70
        Bottom of the colour scale, in dB relative to the common maximum.
    columns : int, default 2
        Number of columns of the grid.
    mel : bool, default False
        If True, use the Mel scale.
    n_mels : int, default 80
        Number of Mel bands (only with mel=True).
    windows : list or None, default None
        (nperseg, overlap) pairs for each panel, when they differ.
    stride : (int, int) or None, default None
        (frequencies, time) step to lighten the figure.
    title : str, default "Spettrogrammi a scala comune"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> al.plot_spectrograms([("originale", voice), ("filtrata", voice_hp)], sr, up_to=6000)
    >>> al.plot_spectrograms(versions, sr, mel=True, n_mels=80, columns=1)
    """
    if isinstance(versions, tuple) and isinstance(versions[0], str):
        versions = [versions]
    computed = []
    for k, (_, y) in enumerate(versions):
        y = np.asarray(y, dtype=float)
        p, o = windows[k] if windows is not None else (nperseg, overlap)
        if mel:
            M = librosa.feature.melspectrogram(
                y=y, sr=sr, n_fft=p, hop_length=p - o, n_mels=n_mels
            )
            t = np.arange(M.shape[1]) * (p - o) / sr
            computed.append((t, np.arange(1, n_mels + 1), M))
        else:
            f, t, P = scipy.signal.spectrogram(
                y,
                fs=sr,
                window="hann",
                nperseg=p,
                noverlap=o,
                nfft=nfft,
                scaling="spectrum",
            )
            computed.append((t, f, np.sqrt(np.maximum(P, 0))))
    reference = max(float(z.max()) for _, _, z in computed)
    if mel:
        maps = [
            (t, a, 10 * np.log10(np.maximum(z / reference, 1e-8)))
            for t, a, z in computed
        ]
        description = "dB"
    else:
        maps = [
            (t, f, 20 * np.log10(np.maximum(z / reference, 1e-8)))
            for t, f, z in computed
        ]
        description = "PSD relativa [dB]"
    if stride is not None:
        sf, st = stride
        maps = [(t[::st], f[::sf], z[::sf, ::st]) for t, f, z in maps]
    rows = -(-len(maps) // columns)
    fig = make_subplots(
        rows=rows,
        cols=columns,
        subplot_titles=[name for name, _ in versions]
        + [""] * (rows * columns - len(maps)),
    )
    for k, (t, f, z) in enumerate(maps):
        r, c = k // columns + 1, k % columns + 1
        fig.add_trace(go.Heatmap(x=t, y=f, z=z, coloraxis="coloraxis"), row=r, col=c)
        fig.update_xaxes(title_text="Tempo [s]", row=r, col=c)
        if mel:
            fig.update_yaxes(title_text="banda Mel", row=r, col=c)
        else:
            fig.update_yaxes(title_text="Frequenza [Hz]", row=r, col=c)
            if up_to is not None:
                fig.update_yaxes(range=[0, up_to], row=r, col=c)
    for k in range(len(maps), rows * columns):
        fig.update_xaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
        fig.update_yaxes(visible=False, row=k // columns + 1, col=k % columns + 1)
    fig.update_layout(
        height=320 * rows,
        coloraxis=dict(
            colorscale="Magma", cmin=floor, cmax=0, colorbar=dict(title=description)
        ),
        title=title,
    )
    return fig


def plot_spectrogram(signal, sr, n_fft=2048, hop=None, up_to=None, mel=False,
                     n_mels=80, title="Spettrogramma"):
    """Plotly-style spectrogram: time-frequency map with colours in decibels.

    With ``mel=True`` the map is a Mel spectrogram: the ordinates are the bands
    instead of the linear STFT grid.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    n_fft : int, default 2048
        Analysis window length.
    hop : int or None, default None
        Hop between windows; when absent, one quarter of n_fft.
    up_to : float or None, default None
        Upper limit of the frequency axis, in Hz (ignored with mel=True).
    mel : bool, default False
        If True, use the Mel spectrogram.
    n_mels : int, default 80
        Number of Mel bands (only with mel=True).
    title : str, default "Spettrogramma"
        Title of the figure.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> signal, sr = al.load_audio(al.AUDIO_DIR / "speech1.wav")
    >>> al.plot_spectrogram(signal, sr, up_to=6000)
    >>> al.plot_spectrogram(signal, sr, mel=True, n_mels=80)
    """
    hop = hop or n_fft // 4
    if mel:
        M = librosa.feature.melspectrogram(
            y=np.asarray(signal, dtype=float),
            sr=sr,
            n_fft=n_fft,
            hop_length=hop,
            n_mels=n_mels,
        )
        db = librosa.power_to_db(M, ref=np.max)
        times = np.arange(db.shape[1]) * hop / sr
        fig = go.Figure(
            go.Heatmap(
                x=times,
                y=np.arange(1, n_mels + 1),
                z=db,
                colorscale="Magma",
                colorbar=dict(title="dB"),
            )
        )
        fig.update_yaxes(title_text="banda Mel")
        fig.update_layout(title=title, xaxis_title="tempo [s]", height=420)
        return fig
    S = librosa.stft(np.asarray(signal, dtype=float), n_fft=n_fft, hop_length=hop)
    Sdb = librosa.amplitude_to_db(np.abs(S), ref=np.max)
    times = np.arange(Sdb.shape[1]) * hop / sr
    freq = np.arange(Sdb.shape[0]) * sr / n_fft
    fig = go.Figure(
        go.Heatmap(
            x=times, y=freq, z=Sdb, colorscale="Magma", colorbar=dict(title="dB")
        )
    )
    if up_to:
        fig.update_yaxes(range=[0, up_to])
    fig.update_layout(
        title=title, xaxis_title="tempo [s]", yaxis_title="frequenza [Hz]", height=420
    )
    return fig


def spectrogram_levels(A, sr, hop=256, reference=None, floor=-80, axis="linear",
                       title="Spettrogramma a livelli", low=80, up_to=8000):
    """Time-frequency map in dB of an already computed STFT, with fixed reference and scale.

    Useful to compare spectrograms on the same scale: the reference can be
    common (the given maximum) or the maximum of the matrix itself. With
    ``axis="log"`` the frequencies use a logarithmic scale.

    Parameters
    ----------
    A : numpy.ndarray
        The STFT (one column per instant; complex values are taken in modulus).
    sr : int
        The sampling rate in Hz.
    hop : int, default 256
        Hop between windows, in samples.
    reference : float or None, default None
        The reference value for the decibels; when absent, the maximum of the
        matrix.
    floor : float, default -80
        Bottom of the colour scale, in dB.
    axis : str, default "linear"
        "linear" or "log" for the frequency axis.
    title : str, default "Spettrogramma a livelli"
        Title of the figure.
    low, up_to : float
        Frequency range shown, in Hz.

    show : bool, default True
        Display the figure in the notebook; with ``show=False`` the function
        only returns it.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure when ``show=False``; with the default ``show=True`` the
        figure is displayed and ``None`` is returned.

    Examples
    --------
    >>> y, sr = al.load_audio(al.AUDIO_DIR / "C-major-scale.wav", sr=22050)
    >>> S = librosa.stft(y, n_fft=2048, hop_length=256)
    >>> al.spectrogram_levels(abs(S), sr, hop=256, title="Scala di do")
    """
    A = np.abs(np.asarray(A))
    ref = float(A.max()) if reference is None else float(reference)
    db = 20 * np.log10(np.maximum(A, np.finfo(float).tiny) / ref)
    times = np.arange(A.shape[1]) * hop / sr
    freq = np.arange(A.shape[0]) * (sr / (2 * (A.shape[0] - 1)))
    fig = go.Figure(
        go.Heatmap(
            x=times,
            y=freq,
            z=db,
            colorscale="Magma",
            zmin=floor,
            zmax=0,
            colorbar=dict(title="dB"),
        )
    )
    fig.update_yaxes(
        type=axis,
        range=[np.log10(low), np.log10(up_to)] if axis == "log" else [low, up_to],
        title_text="frequenza [Hz]",
    )
    fig.update_xaxes(title_text="tempo [s]")
    fig.update_layout(height=420, title=title)
    return fig


def fundamental_frequency(signal, sr, f0=261.63, width=15):
    """Frequency of the highest spectral peak in a band around the expected value.

    Useful when the fundamental is not the absolute maximum: only the band
    ``f0 +/- width`` is searched, instead of the global peak.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (mono).
    sr : int
        The sampling rate in Hz.
    f0 : float, default 261.63
        The expected frequency of the fundamental, in Hz (261.63 = middle C).
    width : float, default 15
        Half width of the search band, in Hz.

    Returns
    -------
    float
        The frequency of the peak found, in Hz.

    Examples
    --------
    >>> y, sr = al.load_audio(al.AUDIO_DIR / "Flute_C4.wav", sr=22050)
    >>> print(round(al.fundamental_frequency(y, sr), 1), "Hz")
    """
    f, s = db_spectrum(signal, sr, n=16384)
    band = (f > f0 - width) & (f < f0 + width)
    return float(f[band][np.argmax(s[band])])


def harmonic_levels(signal, sr, f0=261.63, count=8):
    """Amplitude of the first harmonics in decibels, relative to the fundamental.

    For every multiple of ``f0`` it takes the local maximum of the spectrum in
    a small window around the theoretical frequency of the harmonic.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (mono).
    sr : int
        The sampling rate in Hz.
    f0 : float, default 261.63
        The frequency of the fundamental, in Hz.
    count : int, default 8
        How many harmonics to measure.

    Returns
    -------
    numpy.ndarray
        A vector of ``count`` values in dB, with the fundamental at 0 dB.

    Examples
    --------
    >>> y, sr = al.load_audio(al.AUDIO_DIR / "Trumpet_C4.wav", sr=22050)
    >>> profile = al.harmonic_levels(y, sr)
    >>> print(np.round(profile, 1), "dB")
    """
    f, s = db_spectrum(signal, sr, n=16384)
    values = []
    for n in range(1, count + 1):
        i = np.argmin(np.abs(f - f0 * n))
        window = slice(max(0, i - 3), i + 4)
        values.append(s[window].max())
    return np.array(values) - values[0]


def spectrum_slope(signal, sr, low=200, high=4000, n=16384):
    """Slope of the spectrum in dB per octave, in the given band.

    Estimated with a regression of 10 log10(P) on log2(f): a white noise has a
    slope close to 0, a pink noise close to -3 dB per octave.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (mono).
    sr : int
        The sampling rate in Hz.
    low : float, default 200
        Lower end of the measurement band, in Hz.
    high : float, default 4000
        Upper end of the measurement band, in Hz.
    n : int, default 16384
        Number of samples analysed (padded when the signal is shorter).

    Returns
    -------
    float
        The slope in dB per octave.

    Examples
    --------
    >>> x = al.white_noise(16384, seed=3)
    >>> print(round(al.spectrum_slope(x, 22050), 1), "dB per ottava")
    """
    n = int(n)
    chunk = np.asarray(signal)[:n]
    if len(chunk) < n:
        chunk = np.pad(chunk, (0, n - len(chunk)))
    f = np.fft.rfftfreq(n, 1 / sr)
    P = np.abs(np.fft.rfft(chunk * np.hanning(n))) ** 2
    band = (f >= low) & (f <= high)
    a, _ = np.polyfit(np.log2(f[band]), 10 * np.log10(P[band] + 1e-20), 1)
    return float(a)


plot_spectrum = _autoshow(plot_spectrum)
plot_spectra = _autoshow(plot_spectra)
plot_spectrograms = _autoshow(plot_spectrograms)
plot_spectrogram = _autoshow(plot_spectrogram)
spectrogram_levels = _autoshow(spectrogram_levels)
