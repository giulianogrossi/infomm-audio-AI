"""Signal generation and basic transformations.

Pure tones, noises, harmonic sums, envelopes, quantisation, resampling and the
small synthetic instruments used by the lessons.
"""

import numpy as np
import sys
if sys.platform == "emscripten":
    from . import analysis as librosa
else:
    import librosa

from .constants import SAMPLE_RATE, STANDARD_RATES


def _rng(seed):
    """Internal: the random generator from a seed (or an existing generator)."""
    if isinstance(seed, np.random.Generator):
        return seed
    return np.random.default_rng(seed)


def time_axis(duration, sr=SAMPLE_RATE):
    """Time axis in seconds for a synthetic signal of a given duration.

    Parameters
    ----------
    duration : float
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The sample instants, from 0 to just below ``duration``.

    Examples
    --------
    >>> t = al.time_axis(0.02)
    >>> print(len(t), "istanti, da", t[0], "a", round(t[-1], 4))
    """
    return np.arange(int(round(duration * sr))) / sr


def sine(frequency, duration, sr=SAMPLE_RATE, amplitude=0.5):
    """Generate a pure tone at a given frequency.

    Parameters
    ----------
    frequency : float
        Frequency of the tone in Hz.
    duration : float
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate of the generated signal.
    amplitude : float, default 0.5
        Peak amplitude (0-1).

    Returns
    -------
    numpy.ndarray
        The tone as ``float32``.

    Examples
    --------
    >>> tone = al.sine(440, 0.5)
    >>> print(len(tone), "campioni")
    """
    t = np.arange(int(duration * sr)) / sr
    return (amplitude * np.sin(2 * np.pi * frequency * t)).astype(np.float32)


def sum_tones(frequencies, duration, sr=SAMPLE_RATE, amplitude=0.5):
    """Sum several pure tones, all with the same amplitude.

    The overall amplitude is divided by the number of tones, so the sum does
    not saturate.

    Parameters
    ----------
    frequencies : list of float
        The tone frequencies, in Hz.
    duration : float
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    amplitude : float, default 0.5
        Overall amplitude (shared between the tones).

    Returns
    -------
    numpy.ndarray
        The sum of the tones as ``float32``.

    Examples
    --------
    >>> beat = al.sum_tones([440, 443], 1.0)
    >>> al.listen(beat, al.SAMPLE_RATE)
    """
    t = np.arange(int(duration * sr)) / sr
    total = sum(np.sin(2 * np.pi * f * t) for f in frequencies)
    return (amplitude * total / len(frequencies)).astype(np.float32)


def chirp(f0=200.0, f1=2000.0, duration=1.0, sr=SAMPLE_RATE, amplitude=0.5):
    """Linearly swept tone: a chirp from one frequency to another.

    The phase is quadratic, ``x(t) = cos(2*pi*(f0*t + k*t**2/2))`` with
    ``k = (f1 - f0) / duration``; the instantaneous frequency
    ``f(t) = f0 + k*t`` moves from ``f0`` to ``f1`` in ``duration`` seconds.

    Parameters
    ----------
    f0 : float, default 200.0
        Starting frequency, in Hz.
    f1 : float, default 2000.0
        Ending frequency, in Hz.
    duration : float
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate of the generated signal.
    amplitude : float, default 0.5
        Peak amplitude (0-1).

    Returns
    -------
    numpy.ndarray
        The chirp as ``float32``.

    Examples
    --------
    >>> sweep = al.chirp(300, 2400, 1.0, sr=16000)
    >>> al.listen(sweep, 16000)

    Notes
    -----
    ``k`` is expressed in Hz/s. The signal behaves like a sine whose
    frequency grows (or shrinks) linearly: in a spectrogram it appears as a
    diagonal line with slope ``k``.
    """
    t = np.arange(int(duration * sr)) / sr
    k = (f1 - f0) / duration
    phase = 2 * np.pi * (f0 * t + k * t ** 2 / 2)
    return (amplitude * np.cos(phase)).astype(np.float32)


def envelope(signal, sr, window=0.02):
    """Follow the level of the signal over time, averaging over a short window.

    Useful to see beats and the energy trend.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    window : float, default 0.02
        Length of the averaging window, in seconds.

    Returns
    -------
    numpy.ndarray
        The envelope (root of the moving average of the square).

    Examples
    --------
    >>> beat = al.sum_tones([440, 443], 1.5)
    >>> env = al.envelope(beat, al.SAMPLE_RATE, 0.05)
    >>> al.plot_waveform(env, al.SAMPLE_RATE, "Inviluppo del battimento")
    """
    signal = np.asarray(signal, dtype=float)
    n = max(1, int(window * sr))
    return np.sqrt(np.convolve(signal**2, np.ones(n) / n, mode="same"))


def quantize(signal, bits):
    """Reduce the amplitude resolution to a given number of bits, on [-1, 1].

    It is the quantisation noise, for those who want to hear it.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal (values in [-1, 1]).
    bits : int
        Number of bits of the quantisation.

    Returns
    -------
    numpy.ndarray
        The quantised signal, ``float32``.

    Examples
    --------
    >>> rough = al.quantize(al.sine(440, 0.5), 4)
    >>> al.listen(rough, al.SAMPLE_RATE)
    """
    step = 2 / 2**bits
    return (np.round(np.asarray(signal, dtype=float) / step) * step).astype(np.float32)


def downsample(signal, factor):
    """Take one sample every ``factor``, without filtering.

    Shows what happens when the number of samples is reduced without
    anti-aliasing.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    factor : int
        Decimation step (1 = no reduction).

    Returns
    -------
    numpy.ndarray
        The shortened signal, without filtering.

    Examples
    --------
    >>> reduced = al.downsample(al.sine(440, 0.1), 4)
    >>> print(len(reduced), "campioni")
    """
    return np.asarray(signal)[::factor]


def resample(signal, orig_sr, target_sr):
    """Change the sampling rate, filtering before reducing (anti-aliasing).

    The comparison with ``downsample`` shows the difference between resampling
    and throwing samples away.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    orig_sr : int
        Its sampling rate.
    target_sr : int
        The desired rate.

    Returns
    -------
    numpy.ndarray
        The resampled signal, ``float32``.

    Examples
    --------
    >>> down = al.resample(al.sine(440, 0.5), al.SAMPLE_RATE, 8000)
    >>> print(len(down), "campioni a 8 kHz")
    """
    return librosa.resample(
        np.asarray(signal, dtype=float), orig_sr=orig_sr, target_sr=target_sr
    ).astype(np.float32)


def nyquist_rate(max_frequency):
    """Minimum sampling rate required by the Nyquist-Shannon theorem.

    It is twice the maximum frequency.

    Parameters
    ----------
    max_frequency : float
        The maximum frequency to represent, in Hz.

    Returns
    -------
    float
        The minimum rate in Hz.

    Examples
    --------
    >>> print(al.nyquist_rate(4000), "Hz per un suono fino a 4 kHz")
    """
    return 2 * max_frequency


def standard_rate_for(max_frequency):
    """First standard rate of the course that satisfies the sampling theorem.

    Parameters
    ----------
    max_frequency : float
        The maximum frequency to represent, in Hz.

    Returns
    -------
    int or None
        The suitable standard rate (8, 11.025, 16, 22.05, 32, 44.1, 48, 96
        kHz) or None if none is enough.

    Examples
    --------
    >>> print(al.standard_rate_for(5000), "Hz")   # 11025
    """
    required = nyquist_rate(max_frequency)
    return next((rate for rate in STANDARD_RATES if rate >= required), None)


def white_noise(n, seed=None):
    """A white noise of ``n`` samples: independent Gaussian samples, flat spectrum.

    Parameters
    ----------
    n : int
        Number of samples.
    seed : int or None, default None
        Generator seed for reproducible results.

    Returns
    -------
    numpy.ndarray
        The noise (Gaussian values with standard deviation 1).

    Examples
    --------
    >>> x = al.white_noise(22050, seed=42)
    >>> al.listen(0.1 * x, 22050)
    """
    rng = np.random.default_rng(seed)
    return rng.standard_normal(int(n))


def pink_noise(n, seed=None):
    """A pink noise of ``n`` samples: power falling as 1/f (-3 dB per octave).

    Built by spectral synthesis: the frequency components are generated with an
    amplitude scaled as 1/sqrt(f) and the signal is brought back to time with
    the inverse transform.

    Parameters
    ----------
    n : int
        Number of samples.
    seed : int or None, default None
        Generator seed for reproducible results.

    Returns
    -------
    numpy.ndarray
        The pink noise.

    Examples
    --------
    >>> x = al.pink_noise(22050, seed=42)
    >>> al.listen(0.1 * x, 22050)
    """
    n = int(n)
    rng = np.random.default_rng(seed)
    spectrum = rng.standard_normal(n) + 1j * rng.standard_normal(n)
    f = np.fft.rfftfreq(n)
    f[0] = f[1]
    return np.fft.irfft(spectrum[: len(f)] / np.sqrt(f), n)


def sum_harmonics(harmonics, f0=220.0, duration=1.0, sr=SAMPLE_RATE):
    """Sum of the harmonics of a fundamental, with amplitude 1/n and peak normalisation.

    With only the odd harmonics the spectrum is sparser and the sound resembles
    a stopped-pipe instrument (clarinet); with all the harmonics it is fuller.

    Parameters
    ----------
    harmonics : list of int
        The order numbers of the harmonics to sum (1 = fundamental).
    f0 : float, default 220.0
        The frequency of the fundamental, in Hz.
    duration : float, default 1.0
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The signal, normalised to a peak of 1.

    Examples
    --------
    >>> odd = al.sum_harmonics([1, 3, 5, 7])
    >>> al.listen(odd, al.SAMPLE_RATE)
    """
    t = np.arange(int(duration * sr)) / sr
    s = sum((1.0 / n) * np.sin(2 * np.pi * n * f0 * t) for n in harmonics)
    return s / np.max(np.abs(s))


def decaying_tone(f0=261.63, tau=0.15, attack=0.02, duration=2.0, sr=SAMPLE_RATE):
    """Synthetic note with a linear attack and an exponential decay of time constant ``tau``.

    After ``tau`` the tail is about one third; to fall by 20 dB it takes about
    2.303 tau seconds. Useful to verify decay measurements on the RMS.

    Parameters
    ----------
    f0 : float, default 261.63
        Frequency of the note, in Hz.
    tau : float, default 0.15
        Time constant of the decay, in seconds.
    attack : float, default 0.02
        Duration of the linear attack, in seconds.
    duration : float, default 2.0
        Total duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray)
        The times and the signal of the note.

    Examples
    --------
    >>> t, y = al.decaying_tone()
    >>> al.plot_waveform(y, al.SAMPLE_RATE, "Nota con decadimento", seconds=0.5)
    """
    t = np.arange(int(duration * sr)) / sr
    env = np.ones_like(t)
    env[t < attack] = t[t < attack] / attack
    after = t >= attack
    env[after] = np.exp(-(t[after] - attack) / tau)
    return t, np.sin(2 * np.pi * f0 * t) * env


def fade_edges(signal, sr, ms=10):
    """Apply short ramps at the beginning and at the end, to avoid edge clicks.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    sr : int
        The sampling rate in Hz.
    ms : float, default 10
        Duration of the ramps, in milliseconds.

    Returns
    -------
    numpy.ndarray
        The signal with the ramps applied.

    Examples
    --------
    >>> soft = al.fade_edges(al.sine(440, 0.5), al.SAMPLE_RATE)
    """
    signal = np.array(signal, dtype=float, copy=True)
    n = min(int(ms * sr / 1000), len(signal) // 2)
    if n:
        ramp = np.linspace(0, 1, n)
        signal[:n] *= ramp
        signal[-n:] *= ramp[::-1]
    return signal


def tone_with_envelope(f=261.63, duration=1.6, attack=0.02, release=0.8, sr=SAMPLE_RATE):
    """Synthetic note with an attack and an exponential decay.

    A sound more realistic than a pure tone, useful to study the energy in
    time.

    Parameters
    ----------
    f : float, default 261.63
        Frequency of the note, in Hz (261.63 = middle C).
    duration : float, default 1.6
        Duration in seconds.
    attack : float, default 0.02
        Duration of the attack, in seconds.
    release : float, default 0.8
        Decay time, in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    (numpy.ndarray, numpy.ndarray, numpy.ndarray)
        The times, the note and its envelope.

    Examples
    --------
    >>> t, note, env = al.tone_with_envelope()
    >>> al.plot_waveform(note, al.SAMPLE_RATE, "Nota con inviluppo", seconds=0.4)
    """
    t = np.arange(int(duration * sr)) / sr
    env = np.ones_like(t)
    env[t < attack] = t[t < attack] / attack
    after = t > attack
    env[after] = np.exp(-(t[after] - attack) / (release / 5))
    return t, np.sin(2 * np.pi * f * t) * env, env


def add_silence(signal, seconds, sr=SAMPLE_RATE):
    """Append a silence tail: makes reverbs and delays ring to the end on export.

    Parameters
    ----------
    signal : numpy.ndarray
        The signal.
    seconds : float
        Duration of the tail, in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.

    Returns
    -------
    numpy.ndarray
        The lengthened signal.

    Examples
    --------
    >>> longer = al.add_silence(al.sine(440, 0.2), 0.5)
    >>> print(len(longer))
    """
    if seconds < 0:
        raise ValueError("La durata della coda deve essere non negativa.")
    signal = np.asarray(signal)
    pad = [(0, round(seconds * sr))] + [(0, 0)] * (signal.ndim - 1)
    return np.pad(signal, pad)


def midi_to_frequency(m):
    """Frequency in Hz of a MIDI note (note 69 is middle A, 440 Hz).

    Parameters
    ----------
    m : int
        The MIDI note number.

    Returns
    -------
    float
        The frequency in Hz.

    Examples
    --------
    >>> print(al.midi_to_frequency(69))   # 440.0
    """
    return 440.0 * 2 ** ((m - 69) / 12)


def synthetic_timbre(kind, midi_note=None, duration=0.8, sr=SAMPLE_RATE, seed=None, noise=0.02):
    """A synthetic sound in one of the four timbre families of the chapter.

    All the families are built on the same note (when specified), to isolate the
    effect of the harmonic content: flauto (pure sine), clarinetto (odd
    harmonics only), archi (all the harmonics), percussioni (noise with a fast
    decaying envelope). The level is normalised by energy.

    Parameters
    ----------
    kind : str
        "flauto", "clarinetto", "archi" or "percussioni".
    midi_note : int or None, default None
        The note (MIDI number); when absent a random one is chosen.
    duration : float, default 0.8
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    seed : int, numpy.random.Generator or None, default None
        Generator seed, for reproducible results; an existing generator can be
        passed too (successive calls produce different variants).
    noise : float, default 0.02
        Standard deviation of the background noise added.

    Returns
    -------
    numpy.ndarray
        The synthetic signal (``float32``).

    Examples
    --------
    >>> y = al.synthetic_timbre("flauto", midi_note=64, seed=0)
    """
    rng = _rng(seed)
    if midi_note is None:
        midi_note = rng.integers(57, 70)
    f0 = midi_to_frequency(midi_note)
    t = np.arange(int(round(duration * sr))) / sr

    if kind == "flauto":
        y = np.sin(2 * np.pi * f0 * t)
    elif kind == "clarinetto":
        y = sum((1 / k) * np.sin(2 * np.pi * f0 * k * t) for k in (1, 3, 5, 7, 9))
    elif kind == "archi":
        y = sum((1 / k) * np.sin(2 * np.pi * f0 * k * t) for k in range(1, 12))
    elif kind == "percussioni":
        y = np.exp(-t * 12) * rng.normal(size=t.shape)
    else:
        raise ValueError(f"timbro sconosciuto: {kind}")

    if kind != "percussioni":
        attack = max(1, int(0.02 * sr))
        env = np.ones_like(t)
        env[:attack] = np.linspace(0, 1, attack)
        begin = int(0.7 * len(t))
        env[begin:] *= np.linspace(1, 0, len(t) - begin)
        y = y * env
    energy = np.sqrt(np.mean(y**2)) + 1e-9
    y = y / energy * 0.05
    y = y + rng.normal(0, noise, size=y.shape)
    return y.astype(np.float32)


def synthetic_chord(midi_notes, duration=1.2, sr=SAMPLE_RATE, seed=None):
    """A synthetic chord: the sum of some harmonics of each note, with a random
    phase for each partial (so the timbre does not sound too "clean").

    Parameters
    ----------
    midi_notes : list of int
        The notes of the chord (MIDI numbers), for example [60, 64, 67] for a C
        major.
    duration : float, default 1.2
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    seed : int, numpy.random.Generator or None, default None
        Generator seed, for reproducible results.

    Returns
    -------
    numpy.ndarray
        The signal of the chord (``float32``).

    Examples
    --------
    >>> c_major = al.synthetic_chord([60, 64, 67], seed=2)
    """
    rng = _rng(seed)
    t = np.arange(int(round(duration * sr))) / sr
    y = np.zeros_like(t)
    n_harmonics = rng.integers(3, 7)
    for m in midi_notes:
        f0 = midi_to_frequency(m)
        for k in range(1, n_harmonics):
            y += (1 / k) * np.sin(2 * np.pi * f0 * k * t + rng.uniform(0, 2 * np.pi))
    y = y / (np.max(np.abs(y)) + 1e-9) * 0.6
    y = y + rng.normal(0, 0.02, size=y.shape)
    return y.astype(np.float32)


def synthetic_event(kind, duration=1.0, sr=SAMPLE_RATE, seed=None):
    """A synthetic sound event from one of the four toy classes used in the
    metric demos: clacson, sirena, abbaiare, trapano.

    Every call produces a slightly different variant (like different real
    recordings of the same category); the level is normalised by energy, not by
    peak, so the average loudness does not become a class clue.

    Parameters
    ----------
    kind : str
        "clacson", "sirena", "abbaiare" or "trapano".
    duration : float, default 1.0
        Duration in seconds.
    sr : int, default SAMPLE_RATE
        Sampling rate.
    seed : int, numpy.random.Generator or None, default None
        Generator seed, for reproducible results.

    Returns
    -------
    numpy.ndarray
        The signal of the event (``float32``).

    Examples
    --------
    >>> y = al.synthetic_event("sirena", seed=7)
    """
    rng = _rng(seed)
    t = np.arange(int(round(duration * sr))) / sr

    if kind == "clacson":
        f1 = 400 + rng.normal(0, 40)
        f2 = 330 + rng.normal(0, 40)
        y = 0.5 * np.sin(2 * np.pi * f1 * t) + 0.5 * np.sin(2 * np.pi * f2 * t)
    elif kind == "sirena":
        f0, f1 = 500 + rng.normal(0, 60), 1100 + rng.normal(0, 80)
        rate = 0.8 + rng.normal(0, 0.2)
        inst_freq = f0 + (f1 - f0) * 0.5 * (1 + np.sin(2 * np.pi * rate * t))
        phase = 2 * np.pi * np.cumsum(inst_freq) / sr
        y = np.sin(phase)
    elif kind == "abbaiare":
        y = np.zeros_like(t)
        n_bursts = rng.integers(2, 6)
        centres = np.sort(rng.uniform(0.05, duration - 0.1, n_bursts))
        for c in centres:
            width = 0.02 + rng.uniform(0, 0.05)
            env = np.exp(-0.5 * ((t - c) / width) ** 2)
            f0 = 380 + rng.normal(0, 60)
            y += env * np.sin(2 * np.pi * f0 * t)
    elif kind == "trapano":
        f0 = 380 + rng.normal(0, 45)
        mod_rate = 16 + rng.normal(0, 5)
        mod = 0.5 * (1 + np.sign(np.sin(2 * np.pi * mod_rate * t)))
        y = mod * np.sin(2 * np.pi * f0 * t)
    else:
        raise ValueError(f"classe sconosciuta: {kind}")

    energy = np.sqrt(np.mean(y**2)) + 1e-9
    y = y / energy * 0.05
    y = y + rng.normal(0, 0.18, size=y.shape)   # rumore di fondo, piuttosto forte
    return y.astype(np.float32)
