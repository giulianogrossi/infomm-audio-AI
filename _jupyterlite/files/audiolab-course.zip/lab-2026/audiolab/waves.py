"""Physics of sound and waves (lesson 1).

Teaching figures for longitudinal waves, period and wavelength, amplitude,
frequency and phase, and interference. All the functions return a Plotly
figure.
"""

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .synth import time_axis


def longitudinal_wave(frame=0.0, wavelength=1.8, displacement=0.075):
    """A longitudinal wave at one instant.

    Particles as coloured dots (red = compression, blue = rarefaction) and the
    overpressure below.

    Parameters
    ----------
    frame : float, default 0.0
        The instant, in fractions of a period.
    wavelength : float, default 1.8
        Wavelength, in metres.
    displacement : float, default 0.075
        Maximum displacement of the particles.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure; show it with display(fig) or leave it as the last
        expression of the cell.

    Examples
    --------
    >>> al.longitudinal_wave(frame=0.25)
    """
    x0 = np.linspace(0, 7.2, 95)  # equilibrium positions
    k = 2 * np.pi / wavelength
    x = x0 + displacement * np.sin(k * x0 - 2 * np.pi * frame)
    # Overpressure is proportional to -dxi/dx: compression where the spacing shrinks.
    pressure = -np.cos(k * x0 - 2 * np.pi * frame)
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.14,
        subplot_titles=(
            "Particelle: rosso = compressione, blu = rarefazione",
            "Sovrapressione",
        ),
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=np.zeros_like(x),
            mode="markers",
            marker=dict(color=pressure, colorscale="RdBu", cmin=-1, cmax=1, size=9),
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    for gx in x0[::12]:
        fig.add_vline(
            x=gx, line=dict(color="#BBBBBB", width=1, dash="dot"), row=1, col=1
        )
    fig.add_trace(
        go.Scatter(
            x=x0,
            y=pressure,
            mode="lines",
            line=dict(width=2, color="#D9362B"),
            showlegend=False,
        ),
        row=2,
        col=1,
    )
    fig.add_hline(y=0, line=dict(color="black", width=1), row=2, col=1)
    fig.update_yaxes(range=[-0.3, 0.3], showticklabels=False, row=1, col=1)
    fig.update_xaxes(title_text="posizione x [m]", row=2, col=1)
    fig.update_yaxes(title_text="sovrapressione", row=2, col=1)
    fig.update_layout(height=520, title=f"Onda longitudinale — istante {frame:g}")
    return fig


def space_time_demo(freq=200.0, temperature=20.0):
    """Snapshot in space and measurement at one point of the same tone.

    Shows how period and wavelength are linked by the speed of sound
    (c = lambda f).

    Parameters
    ----------
    freq : float, default 200.0
        Frequency of the tone in Hz.
    temperature : float, default 20.0
        Air temperature in degrees: c = 331.3 + 0.606 T m/s.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure; show it with display(fig) or leave it as the last
        expression of the cell.

    Examples
    --------
    >>> al.space_time_demo(freq=200)
    """
    c = 331.3 + 0.606 * temperature
    period = 1 / freq
    wavelength = c / freq
    x = np.linspace(0, 3 * wavelength, 800)
    t = np.linspace(0, 3 * period, 800)
    p_space = np.sin(2 * np.pi * x / wavelength)
    p_time = np.sin(2 * np.pi * freq * t)
    fig = make_subplots(
        rows=1, cols=2, subplot_titles=("Istantanea nello spazio", "Misura in un punto")
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=p_space,
            mode="lines",
            line=dict(width=2, color="#1769C2"),
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    fig.add_vrect(
        x0=0,
        x1=wavelength,
        fillcolor="#1769C2",
        opacity=0.12,
        line_width=0,
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=t * 1000,
            y=p_time,
            mode="lines",
            line=dict(width=2, color="#D47426"),
            showlegend=False,
        ),
        row=1,
        col=2,
    )
    fig.add_vrect(
        x0=0,
        x1=period * 1000,
        fillcolor="#D47426",
        opacity=0.12,
        line_width=0,
        row=1,
        col=2,
    )
    fig.update_xaxes(title_text="x [m]", row=1, col=1)
    fig.update_xaxes(title_text="t [ms]", row=1, col=2)
    fig.update_yaxes(title_text="pressione normalizzata", row=1, col=1)
    fig.update_layout(
        height=400,
        title=f"f={freq:.1f} Hz, c={c:.1f} m/s → λ = {wavelength:.3f} m, T = {period*1000:.3f} ms",
    )
    return fig


def sinusoid_demo(A=1.0, f=5.0, phi=0.0):
    """A sinusoid to plot, to isolate the effect of amplitude, frequency and phase.

    Parameters
    ----------
    A : float, default 1.0
        Amplitude.
    f : float, default 5.0
        Frequency, in cycles per second of the figure.
    phi : float, default 0.0
        Phase, in radians.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure; show it with display(fig) or leave it as the last
        expression of the cell.

    Examples
    --------
    >>> al.sinusoid_demo(A=2, f=5, phi=0)
    """
    t = np.linspace(0, 1, 1800)
    y = A * np.sin(2 * np.pi * f * t + phi)
    fig = go.Figure(
        go.Scatter(x=t, y=y, mode="lines", line=dict(width=2, color="#1769C2"))
    )
    fig.add_hline(y=0, line=dict(color="black", width=1))
    fig.update_xaxes(range=[0, 1], title_text="tempo [s]")
    fig.update_yaxes(range=[-2.1, 2.1], title_text="s(t)")
    fig.update_layout(
        height=360, title=f"A={A:.2f}, f={f:.2f} Hz, φ={phi:.2f} rad; T={1/f:.3f} s"
    )
    return fig


def same_amplitude_demo(freqs=(220, 440, 880), amp=0.15, duration=0.02):
    """Sinusoids at equal amplitude for different frequencies, one below the other.

    Shows that at equal amplitude only the period changes.

    Parameters
    ----------
    freqs : tuple of float, default (220, 440, 880)
        The frequencies to show.
    amp : float, default 0.15
        Common amplitude.
    duration : float, default 0.02
        Duration shown, in seconds.

    Returns
    -------
    plotly.graph_objects.Figure
        The figure; show it with display(fig) or leave it as the last
        expression of the cell.

    Examples
    --------
    >>> al.same_amplitude_demo()
    """
    t = time_axis(duration)
    fig = make_subplots(
        rows=len(freqs),
        cols=1,
        shared_xaxes=True,
        subplot_titles=[f"{f} Hz" for f in freqs],
    )
    for r, f in enumerate(freqs, start=1):
        y = amp * np.sin(2 * np.pi * f * t)
        fig.add_trace(
            go.Scatter(
                x=t * 1000,
                y=y,
                mode="lines",
                line=dict(width=2, color="#1769C2"),
                showlegend=False,
            ),
            row=r,
            col=1,
        )
        fig.update_yaxes(range=[-amp * 1.3, amp * 1.3], row=r, col=1)
    fig.update_xaxes(
        title_text="tempo [ms]", range=[0, duration * 1000], row=len(freqs), col=1
    )
    fig.update_layout(height=560, title="Stessa ampiezza, frequenze diverse")
    return fig


def phase_interference(delta_phi=0.0):
    """Two copies of the same tone summed with a phase difference.

    Shows the components and the sum, with the theoretical peak
    2 |cos(delta_phi / 2)|.

    Parameters
    ----------
    delta_phi : float, default 0.0
        Phase difference between the two copies, in radians (pi = antiphase).

    Returns
    -------
    plotly.graph_objects.Figure
        The figure; show it with display(fig) or leave it as the last
        expression of the cell.

    Examples
    --------
    >>> al.phase_interference(np.pi)
    """
    f = 5
    t = np.linspace(0, 0.6, 1200)
    y1 = np.sin(2 * np.pi * f * t)
    y2 = np.sin(2 * np.pi * f * t + delta_phi)
    total = y1 + y2
    predicted_peak = 2 * abs(np.cos(delta_phi / 2))
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.16,
        subplot_titles=("componenti", "somma"),
    )
    fig.add_trace(
        go.Scatter(x=t, y=y1, mode="lines", line=dict(width=1.4), name="s₁"),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(x=t, y=y2, mode="lines", line=dict(width=1.4), name="s₂"),
        row=1,
        col=1,
    )
    fig.add_trace(
        go.Scatter(
            x=t, y=total, mode="lines", line=dict(width=2, color="black"), name="s₁+s₂"
        ),
        row=2,
        col=1,
    )
    for yline in (predicted_peak, -predicted_peak):
        fig.add_hline(y=yline, line=dict(color="#D9362B", dash="dot"), row=2, col=1)
    fig.update_xaxes(title_text="tempo [s]", row=2, col=1)
    fig.update_yaxes(range=[-2.2, 2.2], row=2, col=1)
    fig.update_layout(
        height=480,
        title=f"Differenza di fase Δφ={delta_phi:.3f} rad — picco teorico {predicted_peak:.3f}",
    )
    return fig
